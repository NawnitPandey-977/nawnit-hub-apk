/**
 * Bikram Sambat (वि.सं. - B.S.) Astronomical Calendar Utilities
 * Official national calendar of Nepal
 */

import NepaliDate from 'nepali-date-converter';
import { getNepalDate } from './nepalTime';

export interface BikramSambatDetails {
  year: number; // e.g. 2083
  yearNp: string; // e.g. "२०८३"
  month: number; // 1-12 (1 = Baisakh, 7 = Kartik)
  monthIndex: number; // 0-11
  monthNameEn: string; // "Kartik"
  monthNameNp: string; // "कार्तिक"
  day: number; // 1-32
  dayNp: string; // "१४"
  dayOfWeekEn: string; // "Saturday"
  dayOfWeekNp: string; // "शनिबार"
  formattedEn: string; // "Saturday, 14 Kartik 2083 BS"
  formattedNp: string; // "शनिबार, १४ कार्तिक २०८३ वि.सं."
  formattedShortEn: string; // "14 Kartik 2083 BS"
  formattedShortNp: string; // "१४ कार्तिक २०८३"
  bsIso: string; // "2083-07-14"
}

export const BS_MONTHS_EN = [
  'Baisakh', 'Jestha', 'Ashadh', 'Shrawan', 'Bhadra', 'Ashwin',
  'Kartik', 'Mangsir', 'Poush', 'Magh', 'Falgun', 'Chaitra'
];

export const BS_MONTHS_NP = [
  'बैशाख', 'जेठ', 'असार', 'श्रावण', 'भाद्र', 'असोज',
  'कार्तिक', 'मंसिर', 'पुष', 'माघ', 'फागुन', 'चैत्र'
];

export const BS_DAYS_EN = [
  'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
];

export const BS_DAYS_NP = [
  'आइतबार', 'सोमबार', 'मंगलबार', 'बुधबार', 'बिहीबार', 'शुक्रबार', 'शनिबार'
];

const NEPALI_DIGITS = ['०', '१', '२', '३', '४', '५', '६', '७', '८', '९'];

/**
 * Converts any standard Arabic numeral integer or string to Devanagari numerals.
 * e.g., 2083 -> "२०८३", 14 -> "१४"
 */
export function toNepaliNumerals(num: number | string): string {
  const str = num.toString();
  return str.replace(/\d/g, digit => NEPALI_DIGITS[parseInt(digit, 10)]);
}

/**
 * Returns complete, verified Bikram Sambat details for any date,
 * accurately synchronized with Nepal Standard Time.
 */
export function getBikramSambatDetails(baseDate?: Date | string): BikramSambatDetails {
  let targetDate: Date;
  if (!baseDate) {
    targetDate = getNepalDate();
  } else if (typeof baseDate === 'string') {
    // If string like "YYYY-MM-DD", treat as midnight or UTC date safely
    const parts = baseDate.split('-').map(Number);
    if (parts.length === 3) {
      targetDate = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2], 6, 0, 0));
    } else {
      targetDate = new Date(baseDate);
    }
  } else {
    targetDate = baseDate;
  }

  try {
    const nd = new NepaliDate(targetDate);
    const bs = nd.getBS();

    const year = bs.year;
    const month = bs.month + 1; // 1-12
    const monthIndex = bs.month; // 0-11
    const day = bs.date;
    const dayOfWeekIdx = typeof bs.day === 'number' ? bs.day : targetDate.getDay();

    const monthNameEn = BS_MONTHS_EN[monthIndex] || nd.format('MMMM');
    const monthNameNp = BS_MONTHS_NP[monthIndex] || 'कार्तिक';
    const dayOfWeekEn = BS_DAYS_EN[dayOfWeekIdx] || 'Saturday';
    const dayOfWeekNp = BS_DAYS_NP[dayOfWeekIdx] || 'शनिबार';

    const yearNp = toNepaliNumerals(year);
    const dayNp = toNepaliNumerals(day);
    const pad = (n: number) => n.toString().padStart(2, '0');
    const bsIso = `${year}-${pad(month)}-${pad(day)}`;

    const formattedEn = `${dayOfWeekEn}, ${day} ${monthNameEn} ${year} BS`;
    const formattedNp = `${dayOfWeekNp}, ${dayNp} ${monthNameNp} ${yearNp} वि.सं.`;
    const formattedShortEn = `${day} ${monthNameEn} ${year} BS`;
    const formattedShortNp = `${dayNp} ${monthNameNp} ${yearNp}`;

    return {
      year,
      yearNp,
      month,
      monthIndex,
      monthNameEn,
      monthNameNp,
      day,
      dayNp,
      dayOfWeekEn,
      dayOfWeekNp,
      formattedEn,
      formattedNp,
      formattedShortEn,
      formattedShortNp,
      bsIso
    };
  } catch (e) {
    console.error('Error calculating Bikram Sambat date:', e);
    // Safe fallback calculation (+56.7 years)
    const fallbackYear = targetDate.getFullYear() + 57;
    return {
      year: fallbackYear,
      yearNp: toNepaliNumerals(fallbackYear),
      month: 7,
      monthIndex: 6,
      monthNameEn: 'Kartik',
      monthNameNp: 'कार्तिक',
      day: 14,
      dayNp: '१४',
      dayOfWeekEn: 'Saturday',
      dayOfWeekNp: 'शनिबार',
      formattedEn: `Saturday, 14 Kartik ${fallbackYear} BS`,
      formattedNp: `शनिबार, १४ कार्तिक ${toNepaliNumerals(fallbackYear)} वि.सं.`,
      formattedShortEn: `14 Kartik ${fallbackYear} BS`,
      formattedShortNp: `१४ कार्तिक ${toNepaliNumerals(fallbackYear)}`,
      bsIso: `${fallbackYear}-07-14`
    };
  }
}

/**
 * Converts a Gregorian YYYY-MM-DD date string into Bikram Sambat formatted string.
 */
export function formatADtoBS(isoDateString: string, lang: 'en' | 'np' = 'en'): string {
  const bs = getBikramSambatDetails(isoDateString);
  return lang === 'np' ? bs.formattedShortNp : bs.formattedShortEn;
}
