import {
  AttendanceRecord,
  AttendanceStatus,
  UserProfile,
  WorkingDaysConfig,
  HolidayItem,
  SecuritySettings,
  ApkItem,
  DownloadTask,
  AppReminder
} from '../types';
import {
  DEFAULT_USER_PROFILE,
  DEFAULT_WORKING_DAYS,
  DEFAULT_HOLIDAYS,
  DEFAULT_SECURITY_SETTINGS,
  DEFAULT_REMINDERS,
  INITIAL_APK_CATALOG,
  generateSeedAttendance
} from '../data/initialData';
import { getDaysInMonth } from './nepalTime';

const STORAGE_KEYS = {
  ATTENDANCE: 'nawnit_hub_attendance_records',
  USER_PROFILE: 'nawnit_hub_user_profile',
  WORKING_DAYS: 'nawnit_hub_working_days',
  HOLIDAYS: 'nawnit_hub_holidays',
  SECURITY: 'nawnit_hub_security_settings',
  APK_CATALOG: 'nawnit_hub_apk_catalog',
  DOWNLOAD_TASKS: 'nawnit_hub_download_tasks',
  REMINDERS: 'nawnit_hub_reminders',
  THEME_MODE: 'nawnit_hub_theme_mode',
  VIEW_MODE: 'nawnit_hub_view_mode' // 'phone' | 'full'
};

export function loadAttendanceRecords(): Record<string, AttendanceRecord> {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
    if (!raw) {
      const seeded = generateSeedAttendance();
      saveAttendanceRecords(seeded);
      return seeded;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load attendance records:', e);
    return generateSeedAttendance();
  }
}

export function saveAttendanceRecords(records: Record<string, AttendanceRecord>): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(records));
  } catch (e) {
    console.error('Failed to save attendance records:', e);
  }
}

export function loadUserProfile(): UserProfile {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    if (!raw) {
      saveUserProfile(DEFAULT_USER_PROFILE);
      return DEFAULT_USER_PROFILE;
    }
    return { ...DEFAULT_USER_PROFILE, ...JSON.parse(raw) };
  } catch (e) {
    console.error('Failed to load user profile:', e);
    return DEFAULT_USER_PROFILE;
  }
}

export function saveUserProfile(profile: UserProfile): void {
  try {
    localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
  } catch (e) {
    console.error('Failed to save user profile:', e);
  }
}

export function loadWorkingDays(): WorkingDaysConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.WORKING_DAYS);
    return raw ? JSON.parse(raw) : DEFAULT_WORKING_DAYS;
  } catch {
    return DEFAULT_WORKING_DAYS;
  }
}

export function saveWorkingDays(config: WorkingDaysConfig): void {
  try {
    localStorage.setItem(STORAGE_KEYS.WORKING_DAYS, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save working days:', e);
  }
}

export function loadHolidays(): HolidayItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.HOLIDAYS);
    return raw ? JSON.parse(raw) : DEFAULT_HOLIDAYS;
  } catch {
    return DEFAULT_HOLIDAYS;
  }
}

export function saveHolidays(holidays: HolidayItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.HOLIDAYS, JSON.stringify(holidays));
  } catch (e) {
    console.error('Failed to save holidays:', e);
  }
}

export function loadSecuritySettings(): SecuritySettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SECURITY);
    return raw ? JSON.parse(raw) : DEFAULT_SECURITY_SETTINGS;
  } catch {
    return DEFAULT_SECURITY_SETTINGS;
  }
}

export function saveSecuritySettings(settings: SecuritySettings): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SECURITY, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save security settings:', e);
  }
}

export function loadApkCatalog(): ApkItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.APK_CATALOG);
    return raw ? JSON.parse(raw) : INITIAL_APK_CATALOG;
  } catch {
    return INITIAL_APK_CATALOG;
  }
}

export function saveApkCatalog(catalog: ApkItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.APK_CATALOG, JSON.stringify(catalog));
  } catch (e) {
    console.error('Failed to save apk catalog:', e);
  }
}

export function loadDownloadTasks(): DownloadTask[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DOWNLOAD_TASKS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveDownloadTasks(tasks: DownloadTask[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.DOWNLOAD_TASKS, JSON.stringify(tasks));
  } catch (e) {
    console.error('Failed to save download tasks:', e);
  }
}

export function loadReminders(): AppReminder[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.REMINDERS);
    return raw ? JSON.parse(raw) : DEFAULT_REMINDERS;
  } catch {
    return DEFAULT_REMINDERS;
  }
}

export function saveReminders(reminders: AppReminder[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.REMINDERS, JSON.stringify(reminders));
  } catch (e) {
    console.error('Failed to save reminders:', e);
  }
}

export function isWorkingDay(date: Date, workingDaysConfig: WorkingDaysConfig): boolean {
  const day = date.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
  switch (day) {
    case 0: return workingDaysConfig.sunday;
    case 1: return workingDaysConfig.monday;
    case 2: return workingDaysConfig.tuesday;
    case 3: return workingDaysConfig.wednesday;
    case 4: return workingDaysConfig.thursday;
    case 5: return workingDaysConfig.friday;
    case 6: return workingDaysConfig.saturday;
    default: return true;
  }
}

export interface MonthStats {
  year: number;
  month: number; // 1-12
  totalDays: number;
  totalWorkingDays: number;
  presentDays: number;
  absentDays: number;
  leaveDays: number;
  holidayDays: number;
  unmarkedDays: number;
  attendancePercentage: number;
  workingDaysList: string[];
}

export function calculateMonthStats(
  year: number,
  month: number, // 1-12
  records: Record<string, AttendanceRecord>,
  workingDays: WorkingDaysConfig,
  holidays: HolidayItem[]
): MonthStats {
  const totalDays = getDaysInMonth(year, month - 1);
  const pad = (n: number) => n.toString().padStart(2, '0');
  
  let workingDaysCount = 0;
  let presentDays = 0;
  let absentDays = 0;
  let leaveDays = 0;
  let holidayDays = 0;
  let unmarkedDays = 0;
  const workingDaysList: string[] = [];

  const holidayDateSet = new Set(holidays.map(h => h.date));

  for (let d = 1; d <= totalDays; d++) {
    const dateObj = new Date(year, month - 1, d);
    const dateStr = `${year}-${pad(month)}-${pad(d)}`;
    const isConfiguredWorkDay = isWorkingDay(dateObj, workingDays);
    const isConfiguredHoliday = holidayDateSet.has(dateStr);
    const record = records[dateStr];

    // Is it officially a working day?
    // Exclude holidays and officially configured non-working days
    const isActuallyWorkingDay = isConfiguredWorkDay && !isConfiguredHoliday;
    
    if (isActuallyWorkingDay) {
      workingDaysCount++;
      workingDaysList.push(dateStr);
    }

    if (record) {
      if (record.status === 'PRESENT') {
        presentDays++;
      } else if (record.status === 'ABSENT') {
        absentDays++;
      } else if (record.status === 'LEAVE') {
        leaveDays++;
      } else if (record.status === 'HOLIDAY') {
        holidayDays++;
      }
    } else {
      if (isConfiguredHoliday || !isConfiguredWorkDay) {
        holidayDays++;
      } else {
        unmarkedDays++;
      }
    }
  }

  // Attendance Percentage = (Present Days / Total Working Days) × 100
  const attendancePercentage = workingDaysCount > 0 
    ? Math.min(100, parseFloat(((presentDays / workingDaysCount) * 100).toFixed(1)))
    : 0;

  return {
    year,
    month,
    totalDays,
    totalWorkingDays: workingDaysCount,
    presentDays,
    absentDays,
    leaveDays,
    holidayDays,
    unmarkedDays,
    attendancePercentage,
    workingDaysList
  };
}

export function calculateStreak(records: Record<string, AttendanceRecord>, todayStr: string): number {
  let streak = 0;
  const sortedDates = Object.keys(records)
    .filter(d => d <= todayStr)
    .sort()
    .reverse();

  for (const date of sortedDates) {
    const rec = records[date];
    if (rec.status === 'PRESENT') {
      streak++;
    } else if (rec.status === 'HOLIDAY') {
      // Holidays don't break attendance streak
      continue;
    } else {
      break;
    }
  }

  return streak;
}

// Export utilities
export function exportToCSV(records: Record<string, AttendanceRecord>): void {
  const headers = ['Date', 'Status', 'Notes', 'Recorded Timestamp'];
  const rows = Object.values(records)
    .sort((a, b) => b.date.localeCompare(a.date))
    .map(r => [
      r.date,
      r.status,
      `"${(r.notes || '').replace(/"/g, '""')}"`,
      new Date(r.timestamp).toISOString()
    ]);

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `nawnit_hub_attendance_${new Date().toISOString().split('T')[0]}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

export function exportToJSON(
  records: Record<string, AttendanceRecord>,
  profile: UserProfile,
  holidays: HolidayItem[],
  workingDays: WorkingDaysConfig
): void {
  const data = {
    exportedAt: new Date().toISOString(),
    version: '1.2.0',
    app: 'Nawnit Hub',
    userProfile: profile,
    workingDays,
    holidays,
    attendanceRecords: records
  };

  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `nawnit_hub_backup_${new Date().toISOString().split('T')[0]}.json`;
  link.click();
  URL.revokeObjectURL(url);
}

export interface ImportResult {
  success: boolean;
  message: string;
  attendanceRecords?: Record<string, AttendanceRecord>;
  userProfile?: UserProfile;
  holidays?: HolidayItem[];
  workingDays?: WorkingDaysConfig;
  count: number;
}

export function parseImportJSON(rawText: string): ImportResult {
  try {
    const data = JSON.parse(rawText);

    // Support both full backup format and direct records map/array
    let parsedRecords: Record<string, AttendanceRecord> = {};

    if (data.attendanceRecords && typeof data.attendanceRecords === 'object') {
      parsedRecords = data.attendanceRecords;
    } else if (Array.isArray(data)) {
      data.forEach((item: any) => {
        if (item.date && item.status) {
          parsedRecords[item.date] = {
            id: item.id || item.date,
            date: item.date,
            status: item.status,
            notes: item.notes || '',
            timestamp: item.timestamp || Date.now()
          };
        }
      });
    } else if (typeof data === 'object') {
      // Check if it's already a map of YYYY-MM-DD -> record
      for (const [key, val] of Object.entries(data)) {
        if (/^\d{4}-\d{2}-\d{2}$/.test(key) && typeof val === 'object' && (val as any).status) {
          parsedRecords[key] = val as AttendanceRecord;
        }
      }
    }

    const count = Object.keys(parsedRecords).length;
    if (count === 0 && !data.userProfile) {
      return {
        success: false,
        message: 'No valid attendance records or profile found in JSON.',
        count: 0
      };
    }

    return {
      success: true,
      message: `Parsed ${count} attendance records successfully.`,
      attendanceRecords: parsedRecords,
      userProfile: data.userProfile,
      holidays: data.holidays,
      workingDays: data.workingDays,
      count
    };
  } catch (err: any) {
    return {
      success: false,
      message: `JSON parse error: ${err.message || 'Invalid format'}`,
      count: 0
    };
  }
}

export function parseImportCSV(csvText: string): ImportResult {
  try {
    const lines = csvText.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
    if (lines.length === 0) {
      return { success: false, message: 'CSV file is empty.', count: 0 };
    }

    const records: Record<string, AttendanceRecord> = {};
    let startIndex = 0;

    // Check if line 0 is a header
    const firstLineLower = lines[0].toLowerCase();
    if (firstLineLower.includes('date') || firstLineLower.includes('status')) {
      startIndex = 1;
    }

    const validStatuses = new Set(['PRESENT', 'ABSENT', 'LEAVE', 'HOLIDAY']);

    for (let i = startIndex; i < lines.length; i++) {
      const line = lines[i];
      // Basic CSV split considering quotes
      const regex = /(?:,|\n|^)("(?:(?:"")*[^"]*)*"|[^",\n]*|(?:\n|$))/g;
      const values: string[] = [];
      let match;
      while ((match = regex.exec(line)) !== null) {
        let val = match[1];
        if (val === undefined || match.index === regex.lastIndex) {
          break;
        }
        if (val.startsWith('"') && val.endsWith('"')) {
          val = val.substring(1, val.length - 1).replace(/""/g, '"');
        }
        values.push(val.trim());
      }

      if (values.length >= 2) {
        const rawDate = values[0];
        const rawStatus = values[1].toUpperCase();
        const notes = values[2] || '';

        // Validate date format YYYY-MM-DD
        if (/^\d{4}-\d{2}-\d{2}$/.test(rawDate) && validStatuses.has(rawStatus)) {
          records[rawDate] = {
            id: rawDate,
            date: rawDate,
            status: rawStatus as AttendanceStatus,
            notes,
            timestamp: Date.now()
          };
        }
      }
    }

    const count = Object.keys(records).length;
    if (count === 0) {
      return {
        success: false,
        message: 'No valid records found. Expected CSV format: Date (YYYY-MM-DD), Status (PRESENT/ABSENT/LEAVE/HOLIDAY), Notes',
        count: 0
      };
    }

    return {
      success: true,
      message: `Parsed ${count} attendance records from CSV.`,
      attendanceRecords: records,
      count
    };
  } catch (err: any) {
    return {
      success: false,
      message: `CSV parsing error: ${err.message || 'Malformed CSV'}`,
      count: 0
    };
  }
}

export function clearAllData(): void {
  localStorage.removeItem(STORAGE_KEYS.ATTENDANCE);
  localStorage.removeItem(STORAGE_KEYS.USER_PROFILE);
  localStorage.removeItem(STORAGE_KEYS.WORKING_DAYS);
  localStorage.removeItem(STORAGE_KEYS.HOLIDAYS);
  localStorage.removeItem(STORAGE_KEYS.SECURITY);
  localStorage.removeItem(STORAGE_KEYS.APK_CATALOG);
  localStorage.removeItem(STORAGE_KEYS.DOWNLOAD_TASKS);
  localStorage.removeItem(STORAGE_KEYS.REMINDERS);
}

