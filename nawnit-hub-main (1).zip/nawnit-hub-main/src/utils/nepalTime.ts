/**
 * Nepal Standard Time (NPT) utilities
 * Time Zone: Asia/Kathmandu (UTC +05:45)
 */

import { getBikramSambatDetails, BikramSambatDetails } from './bikramSambat';

export const NEPAL_UTC_OFFSET_MINUTES = 345; // 5 hours 45 minutes

export interface NepalTimeDetails {
  date: Date;
  year: number;
  month: number; // 1-12
  monthName: string;
  day: number;
  dayOfWeek: string;
  hours: number;
  minutes: number;
  seconds: number;
  formattedTime: string; // "10:45:22 AM"
  formattedTime24: string; // "10:45:22"
  formattedDate: string; // "Saturday, 31 October 2026"
  isoDate: string; // "YYYY-MM-DD"
  greeting: string;
  bs: BikramSambatDetails;
  bsFormattedEn: string; // "Saturday, 14 Kartik 2083 BS"
  bsFormattedNp: string; // "शनिबार, १४ कार्तिक २०८३ वि.सं."
}

export const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

export const DAY_NAMES = [
  'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
];

export function getNepalDate(baseDate: Date = new Date()): Date {
  // Convert device time to UTC, then apply Nepal offset (+5h45m)
  const utcMillis = baseDate.getTime() + (baseDate.getTimezoneOffset() * 60000);
  return new Date(utcMillis + (NEPAL_UTC_OFFSET_MINUTES * 60000));
}

export function getNepalTimeDetails(baseDate: Date = new Date()): NepalTimeDetails {
  const npt = getNepalDate(baseDate);

  const year = npt.getFullYear();
  const month = npt.getMonth() + 1;
  const monthName = MONTH_NAMES[npt.getMonth()];
  const day = npt.getDate();
  const dayOfWeek = DAY_NAMES[npt.getDay()];

  const hours = npt.getHours();
  const minutes = npt.getMinutes();
  const seconds = npt.getSeconds();

  const pad = (n: number) => n.toString().padStart(2, '0');
  const hours12 = hours % 12 || 12;
  const ampm = hours >= 12 ? 'PM' : 'AM';

  const formattedTime = `${pad(hours12)}:${pad(minutes)}:${pad(seconds)} ${ampm}`;
  const formattedTime24 = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
  const formattedDate = `${dayOfWeek}, ${day} ${monthName} ${year}`;
  const isoDate = `${year}-${pad(month)}-${pad(day)}`;

  // Accurate Bikram Sambat conversion
  const bs = getBikramSambatDetails(npt);

  let greeting = 'Hello';
  if (hours >= 4 && hours < 12) {
    greeting = 'Good Morning';
  } else if (hours >= 12 && hours < 17) {
    greeting = 'Good Afternoon';
  } else if (hours >= 17 && hours < 21) {
    greeting = 'Good Evening';
  } else {
    greeting = 'Good Night';
  }

  return {
    date: npt,
    year,
    month,
    monthName,
    day,
    dayOfWeek,
    hours,
    minutes,
    seconds,
    formattedTime,
    formattedTime24,
    formattedDate,
    isoDate,
    greeting,
    bs,
    bsFormattedEn: bs.formattedEn,
    bsFormattedNp: bs.formattedNp
  };
}

export function getDaysInMonth(year: number, monthIndex: number): number {
  return new Date(year, monthIndex + 1, 0).getDate();
}

export function getFirstDayOfMonth(year: number, monthIndex: number): number {
  return new Date(year, monthIndex, 1).getDay(); // 0 = Sunday
}
