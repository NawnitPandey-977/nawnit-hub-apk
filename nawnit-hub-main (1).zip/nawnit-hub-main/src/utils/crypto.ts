/**
 * Security & Cryptographic utilities
 * Simulates Android Keystore-backed PBKDF2 / SHA-256 PIN hashing and file integrity verification.
 */

export async function hashStringSHA256(input: string): Promise<string> {
  try {
    if (window.crypto && window.crypto.subtle) {
      const encoder = new TextEncoder();
      const data = encoder.encode(input + '_nawnit_hub_keystore_salt_v1');
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    }
  } catch {
    // Fallback simple hash for older environments
  }

  // Pure fallback implementation
  let hash = 0;
  for (let i = 0; i < input.length; i++) {
    const char = input.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(16).padStart(64, 'a');
}

export async function verifyPin(enteredPin: string, storedHash: string): Promise<boolean> {
  if (!storedHash) return false;
  const hash = await hashStringSHA256(enteredPin);
  return hash === storedHash;
}

export function formatBytes(bytes: number, decimals: number = 2): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}
