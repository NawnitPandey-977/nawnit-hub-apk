/**
 * NAWNIT HUB
 * Personal Student Dashboard & Productivity Android Application
 * Architecture: Clean MVVM + Room Offline Storage + Nepal Standard Time (UTC+05:45)
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import {
  loadUserProfile,
  saveUserProfile,
  loadAttendanceRecords,
  saveAttendanceRecords,
  loadWorkingDays,
  saveWorkingDays,
  loadHolidays,
  saveHolidays,
  loadSecuritySettings,
  saveSecuritySettings,
  loadApkCatalog,
  saveApkCatalog,
  loadDownloadTasks,
  saveDownloadTasks,
  loadReminders,
  saveReminders
} from './utils/storage';
import {
  UserProfile,
  AttendanceRecord,
  AttendanceStatus,
  WorkingDaysConfig,
  HolidayItem,
  SecuritySettings,
  ApkItem,
  DownloadTask,
  AppReminder,
  TabType
} from './types';
import { getNepalTimeDetails, NepalTimeDetails } from './utils/nepalTime';
import { PhoneFrame } from './components/PhoneFrame';
import { HomeTab } from './components/HomeTab';
import { AttendanceTab } from './components/AttendanceTab';
import { ProgressTab } from './components/ProgressTab';
import { ApkCentreTab } from './components/ApkCentreTab';
import { SettingsTab } from './components/SettingsTab';
import { AppLockModal } from './components/AppLockModal';
import { AndroidProjectModal } from './components/AndroidProjectModal';

export default function App() {
  // Core State
  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [isPhoneMode, setIsPhoneMode] = useState<boolean>(true);
  const [profile, setProfile] = useState<UserProfile>(loadUserProfile);
  const [attendanceRecords, setAttendanceRecords] = useState<Record<string, AttendanceRecord>>(loadAttendanceRecords);
  const [workingDays, setWorkingDays] = useState<WorkingDaysConfig>(loadWorkingDays);
  const [holidays, setHolidays] = useState<HolidayItem[]>(loadHolidays);
  const [securitySettings, setSecuritySettings] = useState<SecuritySettings>(loadSecuritySettings);
  const [apkCatalog, setApkCatalog] = useState<ApkItem[]>(loadApkCatalog);
  const [downloadTasks, setDownloadTasks] = useState<DownloadTask[]>(loadDownloadTasks);
  const [reminders, setReminders] = useState<AppReminder[]>(loadReminders);

  // Live Nepal Time
  const [nepalTime, setNepalTime] = useState<NepalTimeDetails>(getNepalTimeDetails());

  // Security Lock State
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [showPinSetupModal, setShowPinSetupModal] = useState<boolean>(false);

  // Android Studio Project Deliverable Modal
  const [showAndroidStudioModal, setShowAndroidStudioModal] = useState<boolean>(false);

  // Active download intervals reference
  const downloadIntervals = useRef<Record<string, NodeJS.Timeout>>({});

  // 1. Live Nepal Clock Interval
  useEffect(() => {
    const timer = setInterval(() => {
      setNepalTime(getNepalTimeDetails());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // 2. Lock on initial load if PIN enabled
  useEffect(() => {
    if (securitySettings.isPinEnabled && securitySettings.pinHash) {
      setIsLocked(true);
    }
  }, []);

  // 3. Inactivity Auto-Lock check
  const resetInactivity = useCallback(() => {
    if (securitySettings.isPinEnabled && securitySettings.autoLockTimeoutMinutes > 0) {
      setSecuritySettings(prev => {
        const next = { ...prev, lastActiveTimestamp: Date.now() };
        saveSecuritySettings(next);
        return next;
      });
    }
  }, [securitySettings.isPinEnabled, securitySettings.autoLockTimeoutMinutes]);

  useEffect(() => {
    const handleUserActivity = () => resetInactivity();
    window.addEventListener('click', handleUserActivity);
    window.addEventListener('keydown', handleUserActivity);

    // Periodic timeout check
    const interval = setInterval(() => {
      if (
        securitySettings.isPinEnabled &&
        securitySettings.autoLockTimeoutMinutes > 0 &&
        !isLocked
      ) {
        const elapsedMinutes = (Date.now() - securitySettings.lastActiveTimestamp) / 60000;
        if (elapsedMinutes >= securitySettings.autoLockTimeoutMinutes) {
          setIsLocked(true);
        }
      }
    }, 10000);

    return () => {
      window.removeEventListener('click', handleUserActivity);
      window.removeEventListener('keydown', handleUserActivity);
      clearInterval(interval);
    };
  }, [securitySettings, isLocked, resetInactivity]);

  // Attendance Handlers
  const handleMarkAttendance = (dateStr: string, status: AttendanceStatus, notes?: string) => {
    const newRecord: AttendanceRecord = {
      id: dateStr,
      date: dateStr,
      status,
      notes: notes || '',
      timestamp: Date.now()
    };
    const updated = { ...attendanceRecords, [dateStr]: newRecord };
    setAttendanceRecords(updated);
    saveAttendanceRecords(updated);
  };

  const handleSaveAttendanceRecord = (record: AttendanceRecord) => {
    const updated = { ...attendanceRecords, [record.date]: record };
    setAttendanceRecords(updated);
    saveAttendanceRecords(updated);
  };

  const handleDeleteAttendanceRecord = (dateStr: string) => {
    const copy = { ...attendanceRecords };
    delete copy[dateStr];
    setAttendanceRecords(copy);
    saveAttendanceRecords(copy);
  };

  // Profile & Settings Handlers
  const handleUpdateProfile = (newProfile: UserProfile) => {
    setProfile(newProfile);
    saveUserProfile(newProfile);
  };

  const handleUpdateWorkingDays = (newWorkingDays: WorkingDaysConfig) => {
    setWorkingDays(newWorkingDays);
    saveWorkingDays(newWorkingDays);
  };

  const handleUpdateHolidays = (newHolidays: HolidayItem[]) => {
    setHolidays(newHolidays);
    saveHolidays(newHolidays);
  };

  const handleUpdateSecurity = (newSettings: SecuritySettings) => {
    setSecuritySettings(newSettings);
    saveSecuritySettings(newSettings);
  };

  const handleToggleReminder = (reminderId: string) => {
    const updated = reminders.map(r =>
      r.id === reminderId ? { ...r, isEnabled: !r.isEnabled } : r
    );
    setReminders(updated);
    saveReminders(updated);
  };

  const handleRestoreData = (
    records: Record<string, AttendanceRecord>,
    newProfile: UserProfile
  ) => {
    setAttendanceRecords(records);
    saveAttendanceRecords(records);
    setProfile(newProfile);
    saveUserProfile(newProfile);
  };

  // APK Download Manager Handlers
  const handleStartDownload = (apk: ApkItem) => {
    const totalBytes = apk.fileSizeMb * 1024 * 1024;
    const taskId = `task-${apk.id}-${Date.now()}`;
    const newTask: DownloadTask = {
      id: taskId,
      apkId: apk.id,
      apkName: apk.name,
      packageName: apk.packageName,
      version: apk.version,
      progress: 0,
      downloadSpeed: '2.4 MB/s',
      status: 'DOWNLOADING',
      downloadedBytes: 0,
      totalBytes,
      startTime: Date.now(),
      fileName: `${apk.packageName}-v${apk.version}.apk`
    };

    const nextTasks = [newTask, ...downloadTasks.filter(t => t.apkId !== apk.id)];
    setDownloadTasks(nextTasks);
    saveDownloadTasks(nextTasks);

    // Simulate download chunk progression
    let currentBytes = 0;
    const interval = setInterval(() => {
      const chunk = totalBytes * (Math.random() * 0.12 + 0.08); // 8-20% per tick
      currentBytes += chunk;

      if (currentBytes >= totalBytes) {
        clearInterval(interval);
        delete downloadIntervals.current[taskId];

        setDownloadTasks(prev => {
          const finished = prev.map(t =>
            t.id === taskId
              ? {
                  ...t,
                  progress: 100,
                  downloadedBytes: totalBytes,
                  status: 'COMPLETED' as const,
                  downloadSpeed: '0 KB/s'
                }
              : t
          );
          saveDownloadTasks(finished);
          return finished;
        });
      } else {
        const pct = Math.min(99, Math.round((currentBytes / totalBytes) * 100));
        const speed = `${(Math.random() * 1.5 + 2.0).toFixed(1)} MB/s`;

        setDownloadTasks(prev => {
          const inProgress = prev.map(t =>
            t.id === taskId
              ? {
                  ...t,
                  progress: pct,
                  downloadedBytes: currentBytes,
                  downloadSpeed: speed
                }
              : t
          );
          return inProgress;
        });
      }
    }, 400);

    downloadIntervals.current[taskId] = interval;
  };

  const handleRetryDownload = (taskId: string) => {
    const task = downloadTasks.find(t => t.id === taskId);
    if (!task) return;
    const apk = apkCatalog.find(a => a.id === task.apkId);
    if (apk) {
      handleStartDownload(apk);
    }
  };

  const handleRemoveDownloadedFile = (taskId: string) => {
    const updated = downloadTasks.filter(t => t.id !== taskId);
    setDownloadTasks(updated);
    saveDownloadTasks(updated);
  };

  const handleAddApkEntry = (apk: ApkItem) => {
    const updated = [apk, ...apkCatalog];
    setApkCatalog(updated);
    saveApkCatalog(updated);
  };

  return (
    <div className="w-full min-h-screen bg-slate-950 font-sans">
      {/* App Lock Overlay */}
      {isLocked && securitySettings.isPinEnabled && (
        <AppLockModal
          securitySettings={securitySettings}
          onUnlocked={() => setIsLocked(false)}
          onUpdateSecurity={handleUpdateSecurity}
        />
      )}

      {/* PIN Setup Modal */}
      {showPinSetupModal && (
        <AppLockModal
          isInitialSetup
          securitySettings={securitySettings}
          onUnlocked={() => {
            setShowPinSetupModal(false);
            setIsLocked(false);
          }}
          onUpdateSecurity={handleUpdateSecurity}
          onClose={() => setShowPinSetupModal(false)}
        />
      )}

      {/* Android Studio Source & Build Modal */}
      {showAndroidStudioModal && (
        <AndroidProjectModal onClose={() => setShowAndroidStudioModal(false)} />
      )}

      {/* Phone Frame or Full Container */}
      <PhoneFrame
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        isPhoneMode={isPhoneMode}
        onTogglePhoneMode={() => setIsPhoneMode(!isPhoneMode)}
        nepalTime={nepalTime}
      >
        {currentTab === 'home' && (
          <HomeTab
            profile={profile}
            attendanceRecords={attendanceRecords}
            workingDays={workingDays}
            holidays={holidays}
            reminders={reminders}
            onMarkAttendance={handleMarkAttendance}
            onNavigateTab={setCurrentTab}
            onToggleReminder={handleToggleReminder}
            onOpenAndroidStudio={() => setShowAndroidStudioModal(true)}
          />
        )}

        {currentTab === 'attendance' && (
          <AttendanceTab
            attendanceRecords={attendanceRecords}
            workingDays={workingDays}
            holidays={holidays}
            onSaveRecord={handleSaveAttendanceRecord}
            onDeleteRecord={handleDeleteAttendanceRecord}
          />
        )}

        {currentTab === 'progress' && (
          <ProgressTab
            records={attendanceRecords}
            workingDays={workingDays}
            holidays={holidays}
            profile={profile}
          />
        )}

        {currentTab === 'apk' && (
          <ApkCentreTab
            apkCatalog={apkCatalog}
            downloadTasks={downloadTasks}
            onStartDownload={handleStartDownload}
            onRetryDownload={handleRetryDownload}
            onRemoveDownloadedFile={handleRemoveDownloadedFile}
            onAddApkEntry={handleAddApkEntry}
          />
        )}

        {currentTab === 'settings' && (
          <SettingsTab
            profile={profile}
            workingDays={workingDays}
            holidays={holidays}
            securitySettings={securitySettings}
            reminders={reminders}
            records={attendanceRecords}
            onUpdateProfile={handleUpdateProfile}
            onUpdateWorkingDays={handleUpdateWorkingDays}
            onUpdateHolidays={handleUpdateHolidays}
            onUpdateSecurity={handleUpdateSecurity}
            onToggleReminder={handleToggleReminder}
            onRequestPinSetup={() => setShowPinSetupModal(true)}
            onLockNow={() => setIsLocked(true)}
            onRestoreData={handleRestoreData}
            onOpenAndroidStudio={() => setShowAndroidStudioModal(true)}
          />
        )}
      </PhoneFrame>
    </div>
  );
}
