import {
  UserProfile,
  WorkingDaysConfig,
  HolidayItem,
  ApkItem,
  AppReminder,
  SecuritySettings,
  AttendanceRecord
} from '../types';

export const DEFAULT_USER_PROFILE: UserProfile = {
  name: 'Nawnit Pandey',
  studentClass: '9',
  country: 'Nepal',
  timeZone: 'Asia/Kathmandu',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
  rollNumber: '09',
  schoolName: 'Kathmandu Model Academy',
  academicYear: '2026-2027 AD (2083 BS)'
};

export const DEFAULT_WORKING_DAYS: WorkingDaysConfig = {
  sunday: true,
  monday: true,
  tuesday: true,
  wednesday: true,
  thursday: true,
  friday: true,
  saturday: false // Standard weekly holiday in Nepal
};

export const DEFAULT_HOLIDAYS: HolidayItem[] = [
  { id: 'h1', date: '2026-01-01', name: 'International New Year' },
  { id: 'h2', date: '2026-01-11', name: 'Prithvi Jayanti' },
  { id: 'h3', date: '2026-01-30', name: 'Martyrs Day' },
  { id: 'h4', date: '2026-02-16', name: 'Maha Shivaratri' },
  { id: 'h5', date: '2026-03-03', name: 'Holi Festival (Fagu Purnima)' },
  { id: 'h6', date: '2026-04-14', name: 'Nepali New Year (Baisakh 1)' },
  { id: 'h7', date: '2026-05-01', name: 'International Labour Day' },
  { id: 'h8', date: '2026-05-23', name: 'Buddha Jayanti' },
  { id: 'h9', date: '2026-09-19', name: 'Constitution Day (Sambidhan Diwas)' },
  { id: 'h10', date: '2026-10-18', name: 'Dashain Festival (Phulpati)' },
  { id: 'h11', date: '2026-10-19', name: 'Maha Ashtami' },
  { id: 'h12', date: '2026-10-20', name: 'Maha Navami' },
  { id: 'h13', date: '2026-10-21', name: 'Vijaya Dashami (Tika)' },
  { id: 'h14', date: '2026-11-08', name: 'Tihar (Laxmi Puja)' },
  { id: 'h15', date: '2026-11-10', name: 'Tihar (Bhai Tika)' },
  { id: 'h16', date: '2026-12-25', name: 'Christmas Day' }
];

export const DEFAULT_SECURITY_SETTINGS: SecuritySettings = {
  isPinEnabled: false, // User can enable in setup or settings
  pinHash: '', // '1234' hash will be set on enabling
  pinLength: 4,
  isBiometricEnabled: true,
  autoLockTimeoutMinutes: 5,
  lastActiveTimestamp: Date.now()
};

export const DEFAULT_REMINDERS: AppReminder[] = [
  {
    id: 'r1',
    title: 'Daily Morning Attendance Check',
    time: '08:45',
    daysOfWeek: [0, 1, 2, 3, 4, 5], // Sun-Fri
    isEnabled: true,
    type: 'ATTENDANCE_CHECK'
  },
  {
    id: 'r2',
    title: 'Evening Homework & Notes Review',
    time: '19:00',
    daysOfWeek: [0, 1, 2, 3, 4, 5],
    isEnabled: true,
    type: 'STUDY_SESSION'
  },
  {
    id: 'r3',
    title: 'Monthly Progress Summary Review',
    time: '20:30',
    daysOfWeek: [5], // Friday evening
    isEnabled: false,
    type: 'EXAM_PREP'
  }
];

export const INITIAL_APK_CATALOG: ApkItem[] = [
  {
    id: 'apk-1',
    name: 'Nawnit Hub (Release)',
    packageName: 'com.nawnithub.app',
    version: '1.2.0-stable',
    versionCode: 12,
    fileSizeMb: 14.8,
    iconUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=120&q=80',
    description: 'Official student productivity suite with Room database, Nepal Standard Time live clock, biometric lock, and offline attendance tracker.',
    category: 'Official',
    downloadUrl: 'https://github.com/nawnithub/releases/download/v1.2.0/nawnit-hub-v1.2.0.apk',
    sha256: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
    developer: 'Nawnit Pandey & Architecture Team',
    officialSourceUrl: 'https://github.com/nawnithub',
    minSdkVersion: 26, // Android 8.0 Oreo
    targetSdkVersion: 35, // Android 15
    releaseDate: 'October 2026',
    downloadCount: 1420
  },
  {
    id: 'apk-2',
    name: 'Nepal CDC & NCERT Book Reader',
    packageName: 'com.studenthub.nepalbooks',
    version: '2.4.1',
    versionCode: 24,
    fileSizeMb: 22.4,
    iconUrl: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=120&q=80',
    description: 'Offline textbook viewer for Grade 9 & 10 Compulsory Mathematics, Science & Technology, English, Social Studies, and Nepali.',
    category: 'Education',
    downloadUrl: 'https://trusted-mirror.studenthub.np/apks/nepal-cdc-books-v2.4.1.apk',
    sha256: '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8',
    developer: 'Nepal Open Education Initiative',
    officialSourceUrl: 'https://moecdc.gov.np',
    minSdkVersion: 26,
    targetSdkVersion: 34,
    releaseDate: 'September 2026',
    downloadCount: 8900
  },
  {
    id: 'apk-3',
    name: 'SciCalc Pro: Student Calculator',
    packageName: 'org.nawnit.scicalc',
    version: '3.1.0',
    versionCode: 31,
    fileSizeMb: 8.6,
    iconUrl: 'https://images.unsplash.com/photo-1594980596870-8aa52a78d8cd?auto=format&fit=crop&w=120&q=80',
    description: 'Lightweight scientific calculator featuring trigonometric functions, matrix algebra, unit conversions, and algebraic solvers with zero ads.',
    category: 'Tools',
    downloadUrl: 'https://trusted-mirror.studenthub.np/apks/scicalc-pro-v3.1.0.apk',
    sha256: '4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
    developer: 'Nawnit Labs',
    officialSourceUrl: 'https://github.com/nawnitlabs/scicalc',
    minSdkVersion: 24,
    targetSdkVersion: 35,
    releaseDate: 'August 2026',
    downloadCount: 3240
  },
  {
    id: 'apk-4',
    name: 'FocusFlow: Pomodoro & Study Guard',
    packageName: 'com.focusflow.student',
    version: '1.0.8',
    versionCode: 10,
    fileSizeMb: 11.2,
    iconUrl: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=120&q=80',
    description: 'Distraction-free 25/5 study session timer with ambient rain audio, background white noise, and habit tracking analytics.',
    category: 'Productivity',
    downloadUrl: 'https://trusted-mirror.studenthub.np/apks/focusflow-v1.0.8.apk',
    sha256: 'ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d',
    developer: 'Zenith Productivity Works',
    officialSourceUrl: 'https://zenithapps.org',
    minSdkVersion: 26,
    targetSdkVersion: 34,
    releaseDate: 'October 2026',
    downloadCount: 5120
  },
  {
    id: 'apk-5',
    name: 'Offline English-Nepali Dictionary',
    packageName: 'np.dictionary.offline',
    version: '4.0.2',
    versionCode: 42,
    fileSizeMb: 18.5,
    iconUrl: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&w=120&q=80',
    description: 'Comprehensive 120,000+ words bilingual vocabulary with phonetic pronunciation, Nepali Romanized search, and grammar guide.',
    category: 'Education',
    downloadUrl: 'https://trusted-mirror.studenthub.np/apks/nepali-dictionary-v4.0.2.apk',
    sha256: '2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae',
    developer: 'Lumbini Tech Foundation',
    officialSourceUrl: 'https://lumbinitech.np',
    minSdkVersion: 26,
    targetSdkVersion: 35,
    releaseDate: 'September 2026',
    downloadCount: 7800
  }
];

// Helper to seed realistic attendance for October 2026 and prior months
export function generateSeedAttendance(): Record<string, AttendanceRecord> {
  const records: Record<string, AttendanceRecord> = {};
  
  // October 2026 sample data
  const octStatusMap: Record<number, { status: AttendanceRecord['status']; note?: string }> = {
    1: { status: 'PRESENT', note: 'Computer science project started' },
    2: { status: 'PRESENT', note: 'Science practical lab' },
    3: { status: 'HOLIDAY', note: 'Saturday Weekly Off' },
    4: { status: 'PRESENT', note: 'English grammar assessment' },
    5: { status: 'PRESENT', note: 'Maths trigonometry class' },
    6: { status: 'PRESENT', note: 'Social studies presentation' },
    7: { status: 'LEAVE', note: 'Doctor appointment for dental checkup' },
    8: { status: 'PRESENT', note: 'Nepali essay writing' },
    9: { status: 'PRESENT', note: 'Physics test - scored 94%' },
    10: { status: 'HOLIDAY', note: 'Saturday Weekly Off' },
    11: { status: 'PRESENT', note: 'Morning assembly recitation' },
    12: { status: 'PRESENT', note: 'Chemistry experiment on acids/bases' },
    13: { status: 'PRESENT', note: 'Library study hour' },
    14: { status: 'ABSENT', note: 'Fever and viral cold' },
    15: { status: 'PRESENT', note: 'Recovered, returned to class' },
    16: { status: 'PRESENT', note: 'Pre-Dashain school celebrations' },
    17: { status: 'HOLIDAY', note: 'Saturday Weekly Off' },
    18: { status: 'HOLIDAY', note: 'Dashain Festival (Phulpati)' },
    19: { status: 'HOLIDAY', note: 'Maha Ashtami' },
    20: { status: 'HOLIDAY', note: 'Maha Navami' },
    21: { status: 'HOLIDAY', note: 'Vijaya Dashami (Tika)' },
    22: { status: 'HOLIDAY', note: 'Dashain Vacation Day 2' },
    23: { status: 'HOLIDAY', note: 'Dashain Vacation Day 3' },
    24: { status: 'HOLIDAY', note: 'Saturday Weekly Off' },
    25: { status: 'PRESENT', note: 'School reopened after Dashain holidays' },
    26: { status: 'PRESENT', note: 'Mathematics theorem review' },
    27: { status: 'PRESENT', note: 'Biology plant cells diagram' },
    28: { status: 'PRESENT', note: 'Computer programming in C language' },
    29: { status: 'PRESENT', note: 'Physical education and volleyball' },
    30: { status: 'PRESENT', note: 'Weekly quiz competition winner!' },
    31: { status: 'HOLIDAY', note: 'Saturday Weekly Off' }
  };

  for (let d = 1; d <= 31; d++) {
    const dayStr = d.toString().padStart(2, '0');
    const dateStr = `2026-10-${dayStr}`;
    const info = octStatusMap[d];
    if (info) {
      records[dateStr] = {
        id: dateStr,
        date: dateStr,
        status: info.status,
        notes: info.note,
        timestamp: new Date(2026, 9, d, 9, 0, 0).getTime()
      };
    }
  }

  // September 2026 sample data
  for (let d = 1; d <= 30; d++) {
    const dayStr = d.toString().padStart(2, '0');
    const dateStr = `2026-09-${dayStr}`;
    const dayOfWeek = new Date(2026, 8, d).getDay();
    if (dayOfWeek === 6) {
      // Saturday
      records[dateStr] = {
        id: dateStr,
        date: dateStr,
        status: 'HOLIDAY',
        notes: 'Saturday Weekly Off',
        timestamp: new Date(2026, 8, d, 9, 0, 0).getTime()
      };
    } else if (d === 19) {
      records[dateStr] = {
        id: dateStr,
        date: dateStr,
        status: 'HOLIDAY',
        notes: 'Constitution Day (Sambidhan Diwas)',
        timestamp: new Date(2026, 8, d, 9, 0, 0).getTime()
      };
    } else if (d === 7) {
      records[dateStr] = {
        id: dateStr,
        date: dateStr,
        status: 'ABSENT',
        notes: 'Family emergency travel',
        timestamp: new Date(2026, 8, d, 9, 0, 0).getTime()
      };
    } else if (d === 22) {
      records[dateStr] = {
        id: dateStr,
        date: dateStr,
        status: 'LEAVE',
        notes: 'Medical leave approved by principal',
        timestamp: new Date(2026, 8, d, 9, 0, 0).getTime()
      };
    } else {
      records[dateStr] = {
        id: dateStr,
        date: dateStr,
        status: 'PRESENT',
        notes: 'Full day attendance',
        timestamp: new Date(2026, 8, d, 9, 0, 0).getTime()
      };
    }
  }

  return records;
}
