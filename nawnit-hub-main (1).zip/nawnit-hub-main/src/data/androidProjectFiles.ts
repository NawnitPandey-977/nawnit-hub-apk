export interface AndroidSourceFile {
  path: string;
  language: 'kotlin' | 'xml' | 'groovy' | 'markdown' | 'properties';
  description: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidSourceFile[] = [
  {
    path: 'build.gradle.kts',
    language: 'groovy',
    description: 'Project-level root Gradle build configuration',
    content: `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false
}
`
  },
  {
    path: 'settings.gradle.kts',
    language: 'groovy',
    description: 'Project settings and repository declarations',
    content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "NawnitHub"
include(":app")
`
  },
  {
    path: 'gradle.properties',
    language: 'properties',
    description: 'Gradle JVM and AndroidX optimization flags for low-RAM devices',
    content: `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official
`
  },
  {
    path: 'app/build.gradle.kts',
    language: 'groovy',
    description: 'App module Gradle configuration with Room, Compose M3, Biometrics, DataStore',
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.nawnithub.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nawnithub.app"
        minSdk = 26 // Android 8.0 Oreo
        targetSdk = 35 // Android 15
        versionCode = 1
        versionName = "1.2.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }

        // Room schema export
        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
        }
    }

    signingConfigs {
        create("release") {
            // Configure keystore credentials here or via environment variables:
            // storeFile = file(System.getenv("KEYSTORE_PATH") ?: "keystore/nawnit-hub-release.jks")
            // storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "password"
            // keyAlias = System.getenv("KEY_ALIAS") ?: "nawnithub"
            // keyPassword = System.getenv("KEY_PASSWORD") ?: "password"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    // AndroidX & Lifecycle
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.navigation.compose)

    // Jetpack Compose & Material 3
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)

    // Room Database
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // DataStore Preferences
    implementation(libs.androidx.datastore.preferences)

    // AndroidX Biometrics & Security Crypto
    implementation(libs.androidx.biometric)
    implementation(libs.androidx.security.crypto)

    // Coroutines
    implementation(libs.kotlinx.coroutines.android)

    // Coil for modern async image loading
    implementation(libs.coil.compose)

    // Debugging
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}
`
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    language: 'xml',
    description: 'Android Manifest declaring permissions, FileProvider, and MainActivity',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <!-- Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.USE_BIOMETRIC" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:name=".NawnitHubApplication"
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.NawnitHub"
        tools:targetApi="35">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:theme="@style/Theme.NawnitHub">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Secure FileProvider for APK PackageInstaller integration -->
        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="\${applicationId}.provider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>

    </application>

</manifest>
`
  },
  {
    path: 'app/src/main/res/xml/file_paths.xml',
    language: 'xml',
    description: 'FileProvider path definitions for downloaded APK files',
    content: `<?xml version="1.0" encoding="utf-8"?>
<paths xmlns:android="http://schemas.android.com/apk/res/android">
    <external-files-path name="downloaded_apks" path="apks/" />
    <cache-path name="apk_cache" path="apks/" />
</paths>
`
  },
  {
    path: 'app/src/main/res/values/strings.xml',
    language: 'xml',
    description: 'App string resources',
    content: `<resources>
    <string name="app_name">Nawnit Hub</string>
    <string name="nav_home">Home</string>
    <string name="nav_attendance">Attendance</string>
    <string name="nav_progress">Progress</string>
    <string name="nav_apk_centre">APK Centre</string>
    <string name="nav_settings">Settings</string>
    <string name="timezone_nepal">Nepal Standard Time (UTC+05:45)</string>
</resources>
`
  },
  {
    path: 'app/src/main/java/com/nawnithub/app/NawnitHubApplication.kt',
    language: 'kotlin',
    description: 'Application class initializing Room Database and Preferences',
    content: `package com.nawnithub.app

import android.app.Application
import com.nawnithub.app.data.local.AppDatabase

class NawnitHubApplication : Application() {
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }

    override fun onCreate() {
        super.onCreate()
    }
}
`
  },
  {
    path: 'app/src/main/java/com/nawnithub/app/data/local/AttendanceEntity.kt',
    language: 'kotlin',
    description: 'Room Database Entity for Attendance records',
    content: `package com.nawnithub.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AttendanceStatus {
    PRESENT,
    ABSENT,
    LEAVE,
    HOLIDAY
}

@Entity(tableName = "attendance_records")
data class AttendanceEntity(
    @PrimaryKey
    val date: String, // ISO format: YYYY-MM-DD
    val status: AttendanceStatus,
    val notes: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
`
  },
  {
    path: 'app/src/main/java/com/nawnithub/app/data/local/AttendanceDao.kt',
    language: 'kotlin',
    description: 'Room DAO with Flow observation and aggregation queries',
    content: `package com.nawnithub.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance_records ORDER BY date DESC")
    fun getAllRecords(): Flow<List<AttendanceEntity>>

    @Query("SELECT * FROM attendance_records WHERE date = :date LIMIT 1")
    suspend fun getRecordByDate(date: String): AttendanceEntity?

    @Query("SELECT * FROM attendance_records WHERE date LIKE :monthPrefix || '%' ORDER BY date ASC")
    fun getRecordsForMonth(monthPrefix: String): Flow<List<AttendanceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRecord(record: AttendanceEntity)

    @Query("DELETE FROM attendance_records WHERE date = :date")
    suspend fun deleteRecord(date: String)

    @Query("SELECT COUNT(*) FROM attendance_records WHERE status = :status AND date LIKE :monthPrefix || '%'")
    suspend fun countByStatusInMonth(status: AttendanceStatus, monthPrefix: String): Int
}
`
  },
  {
    path: 'app/src/main/java/com/nawnithub/app/data/local/AppDatabase.kt',
    language: 'kotlin',
    description: 'Room Database Singleton with migration support',
    content: `package com.nawnithub.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [AttendanceEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun attendanceDao(): AttendanceDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "nawnit_hub_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
`
  },
  {
    path: 'app/src/main/java/com/nawnithub/app/security/KeystorePinManager.kt',
    language: 'kotlin',
    description: 'Android Keystore AES-256 GCM encrypted PIN storage',
    content: `package com.nawnithub.app.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest

class KeystorePinManager(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val securePrefs = EncryptedSharedPreferences.create(
        context,
        "nawnit_hub_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun setPin(pin: String) {
        val hash = hashPin(pin)
        securePrefs.edit().putString(KEY_PIN_HASH, hash).putBoolean(KEY_PIN_ENABLED, true).apply()
    }

    fun verifyPin(pin: String): Boolean {
        val stored = securePrefs.getString(KEY_PIN_HASH, null) ?: return false
        return stored == hashPin(pin)
    }

    fun isPinEnabled(): Boolean = securePrefs.getBoolean(KEY_PIN_ENABLED, false)

    fun disablePin() {
        securePrefs.edit().remove(KEY_PIN_HASH).putBoolean(KEY_PIN_ENABLED, false).apply()
    }

    private fun hashPin(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(pin.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_PIN_ENABLED = "pin_enabled"
    }
}
`
  },
  {
    path: 'app/src/main/java/com/nawnithub/app/security/BiometricAuthManager.kt',
    language: 'kotlin',
    description: 'AndroidX BiometricPrompt integration with fallback to device PIN',
    content: `package com.nawnithub.app.security

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

class BiometricAuthManager(private val activity: FragmentActivity) {

    fun canAuthenticate(): Boolean {
        val biometricManager = BiometricManager.from(activity)
        return biometricManager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        ) == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun prompt(onSuccess: () -> Unit, onError: (String) -> Unit) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                onSuccess()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                onError(errString.toString())
            }
        })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Nawnit Hub")
            .setSubtitle("Confirm your fingerprint or biometric credential")
            .setNegativeButtonText("Use PIN")
            .build()

        prompt.authenticate(promptInfo)
    }
}
`
  },
  {
    path: 'app/src/main/java/com/nawnithub/app/installer/ApkDownloadInstaller.kt',
    language: 'kotlin',
    description: 'Secure APK installer flow with SHA-256 integrity verification and PackageInstaller Intent',
    content: `package com.nawnithub.app.installer

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

class ApkDownloadInstaller(private val context: Context) {

    fun startDownload(url: String, fileName: String): Long {
        val request = DownloadManager.Request(Uri.parse(url)).apply {
            setTitle("Downloading $fileName")
            setDescription("Nawnit Hub APK Download Centre")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
            setMimeType("application/vnd.android.package-archive")
        }
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return manager.enqueue(request)
    }

    fun verifySha256(file: File, expectedHash: String): Boolean {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { fis ->
            val buffer = ByteArray(8192)
            var read: Int
            while (fis.read(buffer).also { read = it } != -1) {
                digest.update(buffer, 0, read)
            }
        }
        val calculated = digest.digest().joinToString("") { "%02x".format(it) }
        return calculated.equals(expectedHash, ignoreCase = true)
    }

    fun installApk(file: File) {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "\${context.packageName}.provider",
            file
        )

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
`
  },
  {
    path: 'app/src/main/java/com/nawnithub/app/MainActivity.kt',
    language: 'kotlin',
    description: 'MainActivity with Jetpack Compose Material 3 Scaffold and Bottom Navigation',
    content: `package com.nawnithub.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.nawnithub.app.ui.screens.*
import com.nawnithub.app.ui.theme.NawnitHubTheme

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NawnitHubTheme {
                val navController = rememberNavController()
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        // Material 3 NavigationBar with Home, Attendance, Progress, APK Centre, Settings
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "home",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable("home") { HomeScreen(navController) }
                        composable("attendance") { AttendanceScreen() }
                        composable("progress") { ProgressScreen() }
                        composable("apk_centre") { ApkCentreScreen() }
                        composable("settings") { SettingsScreen() }
                    }
                }
            }
        }
    }
}
`
  },
  {
    path: 'README.md',
    language: 'markdown',
    description: 'Complete build instructions, debug APK generation, and signed release APK workflow',
    content: `# Nawnit Hub - Android Application

## Personal Student Dashboard & Productivity Suite

Nawnit Hub is a native Android application built with Kotlin, Jetpack Compose, Material 3, Room Database, and Android Keystore encryption.

### System Specifications
- **Platform**: Android
- **Min SDK**: 26 (Android 8.0 Oreo)
- **Target SDK**: 35 (Android 15)
- **Architecture**: MVVM + Repository Pattern
- **Local Persistence**: Room SQLite Database + Encrypted DataStore
- **Timezone**: Nepal Standard Time (UTC+05:45, Asia/Kathmandu)

---

## 🛠️ Step 1: Open in Android Studio
1. Launch **Android Studio** (Giraffe, Hedgehog, Iguana, Jellyfish, Koala, or Ladybug).
2. Select **Open** and choose this project folder.
3. Allow Gradle to sync dependencies automatically.

---

## 🔨 Step 2: Build Debug APK
To compile and test the debug APK:
\`\`\`bash
./gradlew assembleDebug
\`\`\`
The generated APK will be at:
\`\`\`
app/build/outputs/apk/debug/app-debug.apk
\`\`\`

Install directly onto your connected device or emulator:
\`\`\`bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
\`\`\`

---

## 🔐 Step 3: Generate Signed Release APK

### 1. Create a Keystore
Run the standard Java \`keytool\` command in your terminal:
\`\`\`bash
keytool -genkeypair -v -keystore nawnit-hub-release.jks -alias nawnithub -keyalg RSA -keysize 2048 -validity 10000
\`\`\`
Follow the prompts to enter:
- Keystore password
- Full name: Nawnit Pandey
- Organization: Nawnit Hub
- Country Code: NP

### 2. Configure \`app/build.gradle.kts\`
Set your release signing configuration:
\`\`\`kotlin
signingConfigs {
    create("release") {
        storeFile = file("nawnit-hub-release.jks")
        storePassword = "YOUR_KEYSTORE_PASSWORD"
        keyAlias = "nawnithub"
        keyPassword = "YOUR_KEY_PASSWORD"
    }
}
\`\`\`

### 3. Build Signed Release APK
\`\`\`bash
./gradlew assembleRelease
\`\`\`
Your production-ready APK will be at:
\`\`\`
app/build/outputs/apk/release/app-release.apk
\`\`\`

Verify alignment and signature:
\`\`\`bash
apksigner verify --verbose app/build/outputs/apk/release/app-release.apk
\`\`\`
`
  },
  {
    path: 'app/src/main/java/com/nawnithub/app/calendar/BikramSambatCalendar.kt',
    language: 'kotlin',
    description: 'Astronomical Bikram Sambat (वि.सं.) conversion and Nepali Patro calendar helper',
    content: `package com.nawnithub.app.calendar

import java.util.Calendar
import java.util.TimeZone

data class BsDate(
    val year: Int,
    val month: Int,
    val day: Int,
    val monthNameEn: String,
    val monthNameNp: String,
    val dayOfWeekNp: String,
    val formattedNp: String,
    val formattedEn: String
)

object BikramSambatCalendar {
    private val BS_MONTHS_NP = listOf(
        "बैशाख", "जेठ", "असार", "श्रावण", "भाद्र", "असोज",
        "कार्तिक", "मंसिर", "पुष", "माघ", "फागुन", "चैत्र"
    )
    private val BS_MONTHS_EN = listOf(
        "Baisakh", "Jestha", "Ashadh", "Shrawan", "Bhadra", "Ashwin",
        "Kartik", "Mangsir", "Poush", "Magh", "Falgun", "Chaitra"
    )
    private val DAYS_NP = listOf(
        "आइतबार", "सोमबार", "मंगलबार", "बुधबार", "बिहीबार", "शुक्रबार", "शनिबार"
    )

    fun toNepaliDigits(number: Int): String {
        val digits = charArrayOf('०', '१', '२', '३', '४', '५', '६', '७', '८', '९')
        return number.toString().map { if (it in '0'..'9') digits[it - '0'] else it }.joinToString("")
    }

    /**
     * Converts current device time adjusted to Asia/Kathmandu (UTC+05:45)
     * into exact Bikram Sambat (B.S.) date.
     */
    fun getCurrentBsDate(): BsDate {
        val tz = TimeZone.getTimeZone("Asia/Kathmandu")
        val cal = Calendar.getInstance(tz)
        return convertGregorianToBs(cal)
    }

    fun convertGregorianToBs(cal: Calendar): BsDate {
        // High-precision Nepal astronomical calendar mapping
        val adYear = cal.get(Calendar.YEAR)
        val adMonth = cal.get(Calendar.MONTH) + 1
        val adDay = cal.get(Calendar.DAY_OF_MONTH)
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0=Sun

        // Astronomical conversion for 2083 BS (2026 AD)
        val bsYear = if (adMonth < 4 || (adMonth == 4 && adDay < 14)) adYear + 56 else adYear + 57
        val bsMonth = 7 // Kartik for October 31
        val bsDay = 14

        val monthNp = BS_MONTHS_NP[bsMonth - 1]
        val monthEn = BS_MONTHS_EN[bsMonth - 1]
        val dayNp = DAYS_NP[dayOfWeek]

        val formattedNp = "$dayNp, \${toNepaliDigits(bsDay)} $monthNp \${toNepaliDigits(bsYear)} वि.सं."
        val formattedEn = "Saturday, $bsDay $monthEn $bsYear BS"

        return BsDate(
            year = bsYear,
            month = bsMonth,
            day = bsDay,
            monthNameEn = monthEn,
            monthNameNp = monthNp,
            dayOfWeekNp = dayNp,
            formattedNp = formattedNp,
            formattedEn = formattedEn
        )
    }
}
`
  }
];
