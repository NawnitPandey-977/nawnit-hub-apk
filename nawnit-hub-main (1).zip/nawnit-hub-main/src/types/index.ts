export type AttendanceStatus = 'PRESENT' | 'ABSENT' | 'LEAVE' | 'HOLIDAY';

export interface AttendanceRecord {
  id: string; // YYYY-MM-DD
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  notes?: string;
  timestamp: number;
  subject?: string;
}

export interface UserProfile {
  name: string;
  studentClass: string;
  country: string;
  timeZone: string;
  avatarUrl: string;
  rollNumber: string;
  schoolName: string;
  academicYear: string;
}

export interface ApkItem {
  id: string;
  name: string;
  packageName: string;
  version: string;
  versionCode: number;
  fileSizeMb: number;
  iconUrl: string;
  description: string;
  category: 'Productivity' | 'Education' | 'Tools' | 'Official';
  downloadUrl: string;
  sha256: string;
  developer: string;
  officialSourceUrl: string;
  minSdkVersion: number;
  targetSdkVersion: number;
  releaseDate: string;
  downloadCount: number;
}

export interface DownloadTask {
  id: string;
  apkId: string;
  apkName: string;
  packageName: string;
  version: string;
  progress: number; // 0 - 100
  downloadSpeed: string;
  status: 'PENDING' | 'DOWNLOADING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  downloadedBytes: number;
  totalBytes: number;
  startTime: number;
  error?: string;
  fileName: string;
}

export interface SecuritySettings {
  isPinEnabled: boolean;
  pinHash: string; // SHA-256 hashed
  pinLength: number; // 4 to 6
  isBiometricEnabled: boolean;
  autoLockTimeoutMinutes: number; // 0 = immediately, 1, 5, 15, -1 = never
  lastActiveTimestamp: number;
}

export interface AppReminder {
  id: string;
  title: string;
  time: string; // HH:mm
  daysOfWeek: number[]; // 0=Sun, 1=Mon, ..., 6=Sat
  isEnabled: boolean;
  type: 'ATTENDANCE_CHECK' | 'STUDY_SESSION' | 'EXAM_PREP';
}

export interface WorkingDaysConfig {
  sunday: boolean;
  monday: boolean;
  tuesday: boolean;
  wednesday: boolean;
  thursday: boolean;
  friday: boolean;
  saturday: boolean; // In Nepal, Saturday is the standard weekly weekend/holiday!
}

export interface HolidayItem {
  id: string;
  date: string; // YYYY-MM-DD
  name: string;
  description?: string;
}

export type TabType = 'home' | 'attendance' | 'progress' | 'apk' | 'settings';
