import React from 'react';
import {
  Home,
  Calendar,
  TrendingUp,
  Download,
  Settings,
  Wifi,
  BatteryCharging,
  Maximize2,
  Minimize2,
  Smartphone
} from 'lucide-react';
import { TabType } from '../types';
import { NepalTimeDetails } from '../utils/nepalTime';

interface PhoneFrameProps {
  currentTab: TabType;
  onTabChange: (tab: TabType) => void;
  isPhoneMode: boolean;
  onTogglePhoneMode: () => void;
  nepalTime: NepalTimeDetails;
  children: React.ReactNode;
}

export const PhoneFrame: React.FC<PhoneFrameProps> = ({
  currentTab,
  onTabChange,
  isPhoneMode,
  onTogglePhoneMode,
  nepalTime,
  children
}) => {
  const navItems: { id: TabType; label: string; icon: React.ElementType }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'attendance', label: 'Attendance', icon: Calendar },
    { id: 'progress', label: 'Progress', icon: TrendingUp },
    { id: 'apk', label: 'APK Centre', icon: Download },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start p-2 sm:p-4">
      {/* Top Bar with Mode Switcher */}
      <header className="w-full max-w-4xl flex items-center justify-between py-2 px-3 mb-2 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse" />
          <span className="font-bold text-white tracking-tight">NAWNIT HUB</span>
          <span className="text-[11px] text-amber-300 font-medium hidden sm:inline bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
            वि.सं. {nepalTime.bs.formattedShortNp} ({nepalTime.bs.formattedShortEn})
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onTogglePhoneMode}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition active:scale-95 text-xs font-semibold"
          >
            {isPhoneMode ? (
              <>
                <Maximize2 className="w-3.5 h-3.5 text-indigo-400" />
                <span>Tablet / Expanded View</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
                <span>Android Phone View</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Main Container: Either Phone Frame or Fullscreen */}
      <main
        className={`w-full transition-all duration-300 relative flex flex-col ${
          isPhoneMode
            ? 'max-w-[420px] h-[860px] max-h-[92vh] rounded-[48px] border-[10px] border-slate-800 bg-slate-950 shadow-2xl shadow-indigo-950/40 overflow-hidden ring-1 ring-slate-700'
            : 'max-w-4xl min-h-[85vh] rounded-3xl border border-slate-800 bg-slate-950 shadow-xl overflow-hidden'
        }`}
      >
        {/* Android Status Bar */}
        <div className="h-10 px-6 flex items-center justify-between text-[11px] font-mono text-slate-400 select-none bg-slate-950/90 z-20 shrink-0">
          <div className="font-bold text-slate-200">
            {nepalTime.formattedTime.slice(0, 5)}
          </div>

          {/* Camera Notch for Phone Mode */}
          {isPhoneMode && (
            <div className="w-24 h-4 rounded-full bg-slate-900 border border-slate-800/80 flex items-center justify-center">
              <div className="w-2.5 h-2.5 rounded-full bg-slate-950 ring-1 ring-slate-800" />
            </div>
          )}

          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-indigo-400">5G</span>
            <Wifi className="w-3.5 h-3.5" />
            <div className="flex items-center gap-1 text-[10px]">
              <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
              <span>96%</span>
            </div>
          </div>
        </div>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto px-4 pt-2">
          {children}
        </div>

        {/* Android Material 3 Bottom Navigation Bar */}
        <nav className="absolute bottom-0 left-0 right-0 h-16 bg-slate-900/95 backdrop-blur-md border-t border-slate-800/80 px-2 flex items-center justify-around z-30 shadow-lg">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`flex-1 py-1 flex flex-col items-center justify-center transition-all duration-200 ${
                  isActive ? 'text-indigo-400 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <div
                  className={`px-3.5 py-1 rounded-full transition-all duration-200 ${
                    isActive ? 'bg-indigo-500/20' : 'bg-transparent'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'scale-110' : ''}`} />
                </div>
                <span className="text-[10px] mt-0.5 tracking-tight font-medium">
                  {item.label}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Android Gesture Bar */}
        {isPhoneMode && (
          <div className="h-1 bg-slate-900 flex items-center justify-center pb-1">
            <div className="w-24 h-1 rounded-full bg-slate-600" />
          </div>
        )}
      </main>
    </div>
  );
};
