import React, { useState } from 'react';
import { Lock, Fingerprint, ShieldCheck, AlertCircle, X, KeyRound } from 'lucide-react';
import { verifyPin, hashStringSHA256 } from '../utils/crypto';
import { SecuritySettings } from '../types';

interface AppLockModalProps {
  securitySettings: SecuritySettings;
  onUnlocked: () => void;
  onUpdateSecurity: (settings: SecuritySettings) => void;
  isInitialSetup?: boolean;
  onClose?: () => void;
}

export const AppLockModal: React.FC<AppLockModalProps> = ({
  securitySettings,
  onUnlocked,
  onUpdateSecurity,
  isInitialSetup = false,
  onClose
}) => {
  const [pin, setPin] = useState<string>('');
  const [confirmPin, setConfirmPin] = useState<string>('');
  const [isConfirming, setIsConfirming] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [biometricStatus, setBiometricStatus] = useState<string | null>(null);

  const targetLength = securitySettings.pinLength || 4;

  const handleDigitPress = async (digit: string) => {
    setError('');
    const current = isConfirming ? confirmPin : pin;
    if (current.length >= targetLength) return;

    const nextVal = current + digit;
    if (isConfirming) {
      setConfirmPin(nextVal);
      if (nextVal.length === targetLength) {
        if (nextVal === pin) {
          // Setup completed
          setIsVerifying(true);
          const hash = await hashStringSHA256(nextVal);
          onUpdateSecurity({
            ...securitySettings,
            isPinEnabled: true,
            pinHash: hash,
            lastActiveTimestamp: Date.now()
          });
          setIsVerifying(false);
          onUnlocked();
        } else {
          setError('PINs do not match. Please try again.');
          setConfirmPin('');
          setIsConfirming(false);
          setPin('');
        }
      }
    } else {
      setPin(nextVal);
      if (nextVal.length === targetLength) {
        if (isInitialSetup) {
          setIsConfirming(true);
        } else {
          // Verify existing PIN
          setIsVerifying(true);
          const isValid = await verifyPin(nextVal, securitySettings.pinHash);
          setIsVerifying(false);
          if (isValid) {
            onUnlocked();
          } else {
            setError('Incorrect PIN. Please try again.');
            setPin('');
          }
        }
      }
    }
  };

  const handleDelete = () => {
    if (isConfirming) {
      setConfirmPin(prev => prev.slice(0, -1));
    } else {
      setPin(prev => prev.slice(0, -1));
    }
    setError('');
  };

  const handleBiometric = () => {
    if (!securitySettings.isBiometricEnabled) {
      setError('Biometric authentication is disabled in settings.');
      return;
    }
    setBiometricStatus('Scanning fingerprint sensor...');
    setTimeout(() => {
      setBiometricStatus('Biometric verified successfully!');
      setTimeout(() => {
        onUnlocked();
      }, 400);
    }, 700);
  };

  const currentPin = isConfirming ? confirmPin : pin;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-4">
      <div className="relative w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-6 shadow-2xl text-center">
        {onClose && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-full hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        <div className="mx-auto w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mb-4">
          {isInitialSetup ? <KeyRound className="w-8 h-8" /> : <Lock className="w-8 h-8" />}
        </div>

        <h2 className="text-xl font-bold text-white tracking-tight">
          {isInitialSetup
            ? isConfirming
              ? 'Confirm Your New PIN'
              : 'Create App Lock PIN'
            : 'Nawnit Hub Locked'}
        </h2>
        <p className="text-xs text-slate-400 mt-1 mb-6">
          {isInitialSetup
            ? isConfirming
              ? 'Re-enter the same 4-digit security code'
              : 'Set a 4-digit PIN backed by Android Keystore encryption'
            : 'Enter your 4-digit security PIN or scan fingerprint'}
        </p>

        {/* PIN Indicators */}
        <div className="flex justify-center items-center gap-4 mb-6">
          {Array.from({ length: targetLength }).map((_, i) => (
            <div
              key={i}
              className={`w-4 h-4 rounded-full transition-all duration-200 ${
                i < currentPin.length
                  ? 'bg-indigo-500 scale-110 shadow-lg shadow-indigo-500/50'
                  : 'bg-slate-800 border border-slate-700'
              }`}
            />
          ))}
        </div>

        {error && (
          <div className="flex items-center justify-center gap-1.5 text-xs text-rose-400 mb-4 bg-rose-500/10 py-1.5 px-3 rounded-lg border border-rose-500/20">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {biometricStatus && (
          <div className="flex items-center justify-center gap-1.5 text-xs text-emerald-400 mb-4 bg-emerald-500/10 py-1.5 px-3 rounded-lg border border-emerald-500/20 animate-pulse">
            <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
            <span>{biometricStatus}</span>
          </div>
        )}

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-3 max-w-[260px] mx-auto mb-6">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(num => (
            <button
              key={num}
              type="button"
              disabled={isVerifying}
              onClick={() => handleDigitPress(num)}
              className="w-16 h-16 rounded-2xl bg-slate-800/80 hover:bg-slate-700/80 active:bg-indigo-600 active:text-white border border-slate-700/60 text-lg font-semibold text-slate-200 flex items-center justify-center transition select-none press-scale shadow-sm"
            >
              {num}
            </button>
          ))}
          <button
            type="button"
            onClick={handleBiometric}
            disabled={!securitySettings.isBiometricEnabled || isInitialSetup}
            className={`w-16 h-16 rounded-2xl border text-xs flex flex-col items-center justify-center transition select-none ${
              securitySettings.isBiometricEnabled && !isInitialSetup
                ? 'bg-indigo-500/15 border-indigo-500/30 text-indigo-400 hover:bg-indigo-500/25 active:scale-95'
                : 'bg-slate-800/40 border-slate-800 text-slate-600 opacity-40 cursor-not-allowed'
            }`}
          >
            <Fingerprint className="w-6 h-6 mb-0.5" />
            <span className="text-[10px] font-medium">Touch</span>
          </button>
          <button
            type="button"
            disabled={isVerifying}
            onClick={() => handleDigitPress('0')}
            className="w-16 h-16 rounded-2xl bg-slate-800/80 hover:bg-slate-700/80 active:bg-indigo-600 active:text-white border border-slate-700/60 text-lg font-semibold text-slate-200 flex items-center justify-center transition select-none press-scale shadow-sm"
          >
            0
          </button>
          <button
            type="button"
            disabled={isVerifying}
            onClick={handleDelete}
            className="w-16 h-16 rounded-2xl bg-slate-800/50 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-rose-400 flex items-center justify-center transition select-none press-scale text-xs font-semibold"
          >
            DEL
          </button>
        </div>

        <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
          <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
          <span>Protected with AES-256 Keystore Cryptography</span>
        </div>
      </div>
    </div>
  );
};
