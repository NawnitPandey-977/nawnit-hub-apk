import React, { useState, useEffect } from 'react';
import {
  Clock,
  Calendar,
  CheckCircle2,
  XCircle,
  ClockAlert,
  Sparkles,
  TrendingUp,
  MapPin,
  Bell,
  ChevronRight,
  Shield,
  Award
} from 'lucide-react';
import {
  UserProfile,
  AttendanceRecord,
  AttendanceStatus,
  WorkingDaysConfig,
  HolidayItem,
  AppReminder,
  TabType
} from '../types';
import { getNepalTimeDetails, NepalTimeDetails } from '../utils/nepalTime';
import { calculateMonthStats, calculateStreak } from '../utils/storage';
import confetti from 'canvas-confetti';

interface HomeTabProps {
  profile: UserProfile;
  attendanceRecords: Record<string, AttendanceRecord>;
  workingDays: WorkingDaysConfig;
  holidays: HolidayItem[];
  reminders: AppReminder[];
  onMarkAttendance: (date: string, status: AttendanceStatus, notes?: string) => void;
  onNavigateTab: (tab: TabType) => void;
  onToggleReminder: (reminderId: string) => void;
  onOpenAndroidStudio: () => void;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  profile,
  attendanceRecords,
  workingDays,
  holidays,
  reminders,
  onMarkAttendance,
  onNavigateTab,
  onToggleReminder,
  onOpenAndroidStudio
}) => {
  const [nepalTime, setNepalTime] = useState<NepalTimeDetails>(getNepalTimeDetails());
  const [timeMode24, setTimeMode24] = useState<boolean>(false);
  const [bsLanguageMode, setBsLanguageMode] = useState<'np' | 'en'>('np');

  // Live ticking clock in Nepal Standard Time (UTC+05:45)
  useEffect(() => {
    const timer = setInterval(() => {
      setNepalTime(getNepalTimeDetails());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const todayIso = nepalTime.isoDate;
  const todayRecord = attendanceRecords[todayIso];

  // Current month stats
  const currentMonthStats = calculateMonthStats(
    nepalTime.year,
    nepalTime.month,
    attendanceRecords,
    workingDays,
    holidays
  );

  const streak = calculateStreak(attendanceRecords, todayIso);

  const handleQuickMark = (status: AttendanceStatus) => {
    onMarkAttendance(todayIso, status, 'Quick marked from Home Dashboard');
    if (status === 'PRESENT') {
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.7 }
        });
      } catch {
        // ignore
      }
    }
  };

  const getStatusBadge = (status?: AttendanceStatus) => {
    switch (status) {
      case 'PRESENT':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-3.5 h-3.5" /> Present Today
          </span>
        );
      case 'ABSENT':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-500/15 text-rose-400 border border-rose-500/30">
            <XCircle className="w-3.5 h-3.5" /> Absent Today
          </span>
        );
      case 'LEAVE':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/30">
            <ClockAlert className="w-3.5 h-3.5" /> On Leave
          </span>
        );
      case 'HOLIDAY':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/15 text-indigo-400 border border-indigo-500/30">
            <Sparkles className="w-3.5 h-3.5" /> Holiday / Off
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
            <Clock className="w-3.5 h-3.5 text-amber-400 animate-pulse" /> Not Marked Yet
          </span>
        );
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Top Profile Header */}
      <div className="flex items-center justify-between bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800/80 rounded-2xl p-4 shadow-lg">
        <div
          onClick={() => onNavigateTab('settings')}
          className="flex items-center gap-3 cursor-pointer group"
          title="Click to view & edit profile in Settings"
        >
          <div className="relative">
            <img
              src={profile.avatarUrl}
              alt={profile.name}
              className="w-13 h-13 rounded-2xl object-cover ring-2 ring-indigo-500/50 group-hover:ring-indigo-400 shadow-md transition"
            />
            <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 ring-2 ring-slate-900 flex items-center justify-center">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
            </span>
          </div>
          <div>
            <div className="text-[11px] font-medium text-indigo-400 uppercase tracking-wider flex items-center gap-1">
              <span>{nepalTime.greeting}</span>
              <span>•</span>
              <span className="flex items-center gap-0.5">
                <MapPin className="w-3 h-3 text-rose-400" />
                {profile.country}
              </span>
            </div>
            <h1 className="text-lg font-bold text-white tracking-tight leading-tight group-hover:text-indigo-300 transition">
              {profile.name}
            </h1>
            <p className="text-xs text-slate-400">
              Class {profile.studentClass} • Roll {profile.rollNumber}
            </p>
          </div>
        </div>

        <button
          onClick={onOpenAndroidStudio}
          className="flex flex-col items-center justify-center bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 px-3 py-2 rounded-xl text-xs font-semibold transition active:scale-95"
          title="Inspect and Download Full Android Studio Source Code"
        >
          <Shield className="w-4 h-4 mb-0.5 text-indigo-400" />
          <span className="text-[10px]">Android Project</span>
        </button>
      </div>

      {/* Nepal Standard Time Live Digital Clock Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-900 border border-indigo-500/30 p-5 shadow-xl">
        <div className="absolute top-0 right-0 -mr-8 -mt-8 w-36 h-36 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-8 -mb-8 w-36 h-36 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wide uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                Live NST • UTC+05:45
              </span>
              <span className="text-[11px] text-slate-400">Asia/Kathmandu</span>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setBsLanguageMode(prev => (prev === 'np' ? 'en' : 'np'))}
                className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-300 hover:bg-amber-500/25 border border-amber-500/30 transition active:scale-95"
                title="Toggle Bikram Sambat script (Nepali / English)"
              >
                {bsLanguageMode === 'np' ? 'वि.सं. (नेपाली)' : 'B.S. (English)'}
              </button>
              <button
                onClick={() => setTimeMode24(!timeMode24)}
                className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 hover:text-white border border-slate-700"
              >
                {timeMode24 ? '24H' : '12H'}
              </button>
            </div>
          </div>

          {/* Time Display */}
          <div className="text-center py-2">
            <div className="text-4xl sm:text-5xl font-mono font-extrabold tracking-tight text-white drop-shadow-sm flex items-center justify-center gap-1">
              <span>{timeMode24 ? nepalTime.formattedTime24 : nepalTime.formattedTime.split(' ')[0]}</span>
              {!timeMode24 && (
                <span className="text-xs font-semibold text-indigo-400 self-end mb-1 ml-1">
                  {nepalTime.formattedTime.split(' ')[1]}
                </span>
              )}
            </div>

            {/* Most Accurate Bikram Sambat (B.S.) Date Banner */}
            <div className="mt-2 py-2 px-3 rounded-2xl bg-slate-950/70 border border-amber-500/30 shadow-inner flex flex-col items-center justify-center gap-1">
              <div className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-amber-300 tracking-wide">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>
                  {bsLanguageMode === 'np'
                    ? nepalTime.bsFormattedNp
                    : nepalTime.bsFormattedEn}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-medium">
                <Calendar className="w-3 h-3 text-indigo-400 shrink-0" />
                <span>Gregorian (AD): {nepalTime.formattedDate}</span>
              </div>
            </div>
          </div>

          {/* Today's Attendance Quick Status */}
          <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">Today:</span>
              {getStatusBadge(todayRecord?.status)}
            </div>
            {streak > 0 && (
              <div className="flex items-center gap-1 text-xs font-semibold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20">
                <Award className="w-3.5 h-3.5" />
                <span>{streak} Day Streak</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick Mark Attendance Action Pill Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Mark Today's Attendance
          </h3>
          <div className="flex items-center gap-1.5 text-[10px] font-mono">
            <span className="text-amber-400 font-semibold">{nepalTime.bs.formattedShortNp}</span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-400">{nepalTime.isoDate}</span>
          </div>
        </div>
        <div className="grid grid-cols-4 gap-2">
          <button
            onClick={() => handleQuickMark('PRESENT')}
            className={`py-2 px-1 rounded-xl text-xs font-semibold flex flex-col items-center justify-center gap-1 transition active:scale-95 border ${
              todayRecord?.status === 'PRESENT'
                ? 'bg-emerald-600 text-white border-emerald-500 shadow-md shadow-emerald-500/20'
                : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/25 hover:bg-emerald-500/20'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Present</span>
          </button>
          <button
            onClick={() => handleQuickMark('ABSENT')}
            className={`py-2 px-1 rounded-xl text-xs font-semibold flex flex-col items-center justify-center gap-1 transition active:scale-95 border ${
              todayRecord?.status === 'ABSENT'
                ? 'bg-rose-600 text-white border-rose-500 shadow-md shadow-rose-500/20'
                : 'bg-rose-500/10 text-rose-400 border-rose-500/25 hover:bg-rose-500/20'
            }`}
          >
            <XCircle className="w-4 h-4" />
            <span>Absent</span>
          </button>
          <button
            onClick={() => handleQuickMark('LEAVE')}
            className={`py-2 px-1 rounded-xl text-xs font-semibold flex flex-col items-center justify-center gap-1 transition active:scale-95 border ${
              todayRecord?.status === 'LEAVE'
                ? 'bg-amber-600 text-white border-amber-500 shadow-md shadow-amber-500/20'
                : 'bg-amber-500/10 text-amber-400 border-amber-500/25 hover:bg-amber-500/20'
            }`}
          >
            <ClockAlert className="w-4 h-4" />
            <span>Leave</span>
          </button>
          <button
            onClick={() => handleQuickMark('HOLIDAY')}
            className={`py-2 px-1 rounded-xl text-xs font-semibold flex flex-col items-center justify-center gap-1 transition active:scale-95 border ${
              todayRecord?.status === 'HOLIDAY'
                ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-500/20'
                : 'bg-indigo-500/10 text-indigo-400 border-indigo-500/25 hover:bg-indigo-500/20'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Holiday</span>
          </button>
        </div>
      </div>

      {/* Monthly Attendance Progress Summary Card */}
      <div className="bg-gradient-to-br from-slate-900 to-indigo-950/30 border border-slate-800 rounded-3xl p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="text-[11px] font-semibold text-indigo-400 uppercase tracking-wide">
              {nepalTime.monthName} {nepalTime.year} Progress
            </div>
            <h3 className="text-base font-bold text-white">Monthly Attendance Summary</h3>
          </div>
          <button
            onClick={() => onNavigateTab('progress')}
            className="flex items-center gap-1 text-xs text-indigo-400 hover:text-indigo-300 font-medium"
          >
            <span>Details</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Progress Circle & Rate */}
        <div className="flex items-center justify-between gap-4 p-4 rounded-2xl bg-slate-950/50 border border-slate-800">
          <div className="flex items-center gap-4">
            <div className="relative w-16 h-16 flex items-center justify-center">
              <svg className="w-16 h-16 transform -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-slate-800"
                  strokeWidth="3.8"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className="text-indigo-500"
                  strokeDasharray={`${currentMonthStats.attendancePercentage}, 100`}
                  strokeWidth="3.8"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <span className="absolute text-sm font-bold text-white font-mono">
                {Math.round(currentMonthStats.attendancePercentage)}%
              </span>
            </div>
            <div>
              <div className="text-xs font-semibold text-slate-200 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                Working-Day Rate
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {currentMonthStats.presentDays} of {currentMonthStats.totalWorkingDays} working days present
              </p>
              <p className="text-[10px] text-indigo-300/80 font-mono mt-0.5">
                Formula: (Present / Working) × 100
              </p>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('attendance')}
            className="shrink-0 text-xs px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl transition active:scale-95 shadow-md shadow-indigo-600/30"
          >
            Calendar
          </button>
        </div>

        {/* 4 Quick Stat Counters */}
        <div className="grid grid-cols-4 gap-2 mt-3">
          <div className="bg-slate-900/90 border border-emerald-500/20 rounded-xl p-2.5 text-center">
            <div className="text-lg font-bold text-emerald-400 font-mono">
              {currentMonthStats.presentDays}
            </div>
            <div className="text-[10px] text-slate-400 font-medium">Present</div>
          </div>
          <div className="bg-slate-900/90 border border-rose-500/20 rounded-xl p-2.5 text-center">
            <div className="text-lg font-bold text-rose-400 font-mono">
              {currentMonthStats.absentDays}
            </div>
            <div className="text-[10px] text-slate-400 font-medium">Absent</div>
          </div>
          <div className="bg-slate-900/90 border border-amber-500/20 rounded-xl p-2.5 text-center">
            <div className="text-lg font-bold text-amber-400 font-mono">
              {currentMonthStats.leaveDays}
            </div>
            <div className="text-[10px] text-slate-400 font-medium">Leave</div>
          </div>
          <div className="bg-slate-900/90 border border-indigo-500/20 rounded-xl p-2.5 text-center">
            <div className="text-lg font-bold text-indigo-400 font-mono">
              {currentMonthStats.holidayDays}
            </div>
            <div className="text-[10px] text-slate-400 font-medium">Holidays</div>
          </div>
        </div>
      </div>

      {/* Upcoming Reminders */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
            <Bell className="w-4 h-4 text-indigo-400" />
            Daily Reminders &amp; Alerts
          </h3>
          <span className="text-[10px] text-slate-400">Configured in Settings</span>
        </div>
        <div className="space-y-2">
          {reminders.map(rem => (
            <div
              key={rem.id}
              className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-medium text-slate-200">{rem.title}</div>
                  <div className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                    <span>{rem.time} NPT</span>
                    <span>•</span>
                    <span>Sun–Fri</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => onToggleReminder(rem.id)}
                className={`w-10 h-5 rounded-full transition-colors relative flex items-center p-0.5 ${
                  rem.isEnabled ? 'bg-indigo-600' : 'bg-slate-800'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    rem.isEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
