import React, { useState } from 'react';
import {
  FileCode,
  Download,
  Copy,
  Check,
  FolderTree,
  X,
  Terminal,
  Key,
  ShieldCheck,
  Play
} from 'lucide-react';
import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES, AndroidSourceFile } from '../data/androidProjectFiles';

interface AndroidProjectModalProps {
  onClose: () => void;
}

export const AndroidProjectModal: React.FC<AndroidProjectModalProps> = ({ onClose }) => {
  const [selectedFile, setSelectedFile] = useState<AndroidSourceFile>(ANDROID_PROJECT_FILES[3]); // app/build.gradle.kts
  const [activeTab, setActiveTab] = useState<'explorer' | 'guide'>('explorer');
  const [copied, setCopied] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();

      // Populate files into zip with proper directory hierarchy
      ANDROID_PROJECT_FILES.forEach(file => {
        zip.file(`NawnitHub/${file.path}`, file.content);
      });

      // Add gradle wrapper simulation and extra resources
      zip.file(
        'NawnitHub/gradlew',
        `#!/usr/bin/env sh\n# Gradle start up script for POSIX systems\nexec java -jar gradle/wrapper/gradle-wrapper.jar "$@"\n`
      );
      zip.file('NawnitHub/gradlew.bat', `@rem Gradle startup script for Windows\r\n@"%JAVA_EXE%" -jar gradle\\wrapper\\gradle-wrapper.jar %*\r\n`);

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = `nawnit-hub-android-studio-project.zip`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to generate ZIP archive:', err);
      alert('Error creating ZIP archive.');
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-3 sm:p-6 overflow-y-auto">
      <div className="relative w-full max-w-4xl h-[90vh] rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl flex flex-col overflow-hidden">
        {/* Top Modal Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <FolderTree className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>Android Studio Project Deliverables</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  Ready to Build
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Kotlin 2.0 &bull; Jetpack Compose &bull; Room SQLite &bull; Material 3 &bull; Gradle Kotlin DSL
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-semibold shadow-lg shadow-indigo-600/30 transition disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{isZipping ? 'Packaging ZIP...' : 'Download Project (.zip)'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 px-4 py-2 border-b border-slate-800 bg-slate-950/30 text-xs">
          <button
            onClick={() => setActiveTab('explorer')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition ${
              activeTab === 'explorer'
                ? 'bg-slate-800 text-indigo-400 border border-indigo-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Source Code Explorer
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition ${
              activeTab === 'guide'
                ? 'bg-slate-800 text-indigo-400 border border-indigo-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Build &amp; Signing Guide
          </button>
        </div>

        {/* Content Body */}
        {activeTab === 'explorer' ? (
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            {/* Left Sidebar: File Tree */}
            <div className="w-full md:w-64 border-r border-slate-800 bg-slate-950/40 p-3 overflow-y-auto space-y-1">
              <div className="text-[10px] font-bold text-slate-500 uppercase px-2 mb-2 tracking-wider">
                Project Files ({ANDROID_PROJECT_FILES.length})
              </div>
              {ANDROID_PROJECT_FILES.map(file => {
                const isSelected = selectedFile.path === file.path;
                return (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-mono flex items-center gap-2 transition truncate ${
                      isSelected
                        ? 'bg-indigo-600 text-white font-semibold shadow-md shadow-indigo-600/30'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                    }`}
                  >
                    <FileCode className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{file.path}</span>
                  </button>
                );
              })}
            </div>

            {/* Right: Code Viewer */}
            <div className="flex-1 flex flex-col overflow-hidden bg-slate-950">
              <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800 bg-slate-900/70 text-xs">
                <div>
                  <span className="font-mono font-bold text-white">{selectedFile.path}</span>
                  <span className="text-[10px] text-slate-400 ml-2">({selectedFile.description})</span>
                </div>
                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] transition"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>

              <div className="flex-1 p-4 overflow-auto font-mono text-xs text-slate-300 leading-relaxed select-text">
                <pre className="whitespace-pre">{selectedFile.content}</pre>
              </div>
            </div>
          </div>
        ) : (
          /* Guide Tab */
          <div className="flex-1 p-6 overflow-y-auto space-y-6 text-xs text-slate-300 select-text">
            {/* Step 1 */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <div className="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-xs">
                  1
                </div>
                <span>Open in Android Studio</span>
              </div>
              <p className="text-slate-400 leading-relaxed pl-8">
                Extract the downloaded <code className="text-indigo-300">nawnit-hub-android-studio-project.zip</code>. Launch Android Studio (version Hedgehog, Iguana, Jellyfish, Koala, or Ladybug) and click <strong>Open</strong>. Select the extracted folder and wait for the initial Gradle sync to finish.
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <div className="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-xs">
                  2
                </div>
                <span>Build &amp; Run Debug APK</span>
              </div>
              <p className="text-slate-400 leading-relaxed pl-8">
                To build the debug APK via command line:
              </p>
              <div className="ml-8 p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-indigo-300 flex items-center justify-between">
                <span>./gradlew assembleDebug</span>
                <Terminal className="w-4 h-4 text-slate-500" />
              </div>
              <p className="text-[11px] text-slate-500 pl-8">
                Output path: <code className="text-slate-400">app/build/outputs/apk/debug/app-debug.apk</code>
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <div className="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-xs">
                  3
                </div>
                <span>Generate Signed Release APK</span>
              </div>
              <p className="text-slate-400 leading-relaxed pl-8">
                Generate an Android Keystore using Java's <code className="text-indigo-300">keytool</code>:
              </p>
              <div className="ml-8 p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-indigo-300 break-all text-[11px]">
                keytool -genkeypair -v -keystore nawnit-hub-release.jks -alias nawnithub -keyalg RSA -keysize 2048 -validity 10000
              </div>
              <p className="text-slate-400 leading-relaxed pl-8 mt-2">
                Then run the release assembly task:
              </p>
              <div className="ml-8 p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-indigo-300 flex items-center justify-between">
                <span>./gradlew assembleRelease</span>
                <Key className="w-4 h-4 text-emerald-400" />
              </div>
              <p className="text-[11px] text-slate-500 pl-8">
                Production APK output path: <code className="text-slate-400">app/build/outputs/apk/release/app-release.apk</code>
              </p>
            </div>

            {/* Security checklist */}
            <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                <ShieldCheck className="w-4 h-4" />
                <span>Security &amp; Android 15 Compliance</span>
              </div>
              <ul className="list-disc pl-5 space-y-1 text-emerald-300/90 text-[11px]">
                <li>Zero hardcoded API keys; offline Room database persistence.</li>
                <li>BiometricPrompt API with fallback to Android Keystore AES-256 GCM.</li>
                <li>APK Download Centre uses official Android PackageInstaller with SHA-256 verification.</li>
                <li>Min SDK 26 (Android 8.0) and Target SDK 35 (Android 15) fully configured.</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
