import React, { useState } from 'react';
import {
  TrendingUp,
  Download,
  Calendar,
  CheckCircle2,
  XCircle,
  ClockAlert,
  Sparkles,
  Printer,
  ChevronLeft,
  ChevronRight,
  Info
} from 'lucide-react';
import {
  AttendanceRecord,
  WorkingDaysConfig,
  HolidayItem,
  UserProfile
} from '../types';
import {
  MONTH_NAMES,
  getNepalTimeDetails
} from '../utils/nepalTime';
import { getBikramSambatDetails } from '../utils/bikramSambat';
import {
  calculateMonthStats,
  exportToCSV,
  exportToJSON
} from '../utils/storage';

interface ProgressTabProps {
  records: Record<string, AttendanceRecord>;
  workingDays: WorkingDaysConfig;
  holidays: HolidayItem[];
  profile: UserProfile;
}

export const ProgressTab: React.FC<ProgressTabProps> = ({
  records,
  workingDays,
  holidays,
  profile
}) => {
  const currentNepal = getNepalTimeDetails();
  const [selectedYear, setSelectedYear] = useState<number>(currentNepal.year);
  const [selectedMonth, setSelectedMonth] = useState<number>(currentNepal.month); // 1-12

  const stats = calculateMonthStats(
    selectedYear,
    selectedMonth,
    records,
    workingDays,
    holidays
  );

  // Compare all 12 months in this year
  const yearMonthlyStats = MONTH_NAMES.map((name, idx) => {
    return {
      monthNumber: idx + 1,
      monthName: name,
      shortName: name.slice(0, 3),
      stats: calculateMonthStats(selectedYear, idx + 1, records, workingDays, holidays)
    };
  });

  // Calculate annual summary
  const annualPresent = yearMonthlyStats.reduce((acc, m) => acc + m.stats.presentDays, 0);
  const annualWorking = yearMonthlyStats.reduce((acc, m) => acc + m.stats.totalWorkingDays, 0);
  const annualPercentage = annualWorking > 0
    ? Math.min(100, parseFloat(((annualPresent / annualWorking) * 100).toFixed(1)))
    : 0;

  const handlePrintPDF = () => {
    window.print();
  };

  const handlePrevMonth = () => {
    if (selectedMonth === 1) {
      setSelectedMonth(12);
      setSelectedYear(prev => prev - 1);
    } else {
      setSelectedMonth(prev => prev - 1);
    }
  };

  const handleNextMonth = () => {
    if (selectedMonth === 12) {
      setSelectedMonth(1);
      setSelectedYear(prev => prev + 1);
    } else {
      setSelectedMonth(prev => prev + 1);
    }
  };

  const pad = (n: number) => n.toString().padStart(2, '0');
  const monthBs = getBikramSambatDetails(`${selectedYear}-${pad(selectedMonth)}-15`);

  return (
    <div className="space-y-4 pb-20">
      {/* Month & Year Selection Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[11px] font-semibold text-amber-300 uppercase tracking-wide flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>वि.सं. {monthBs.monthNameNp} {monthBs.yearNp} ({monthBs.monthNameEn} {monthBs.year} BS)</span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              {MONTH_NAMES[selectedMonth - 1]} {selectedYear}
            </h2>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={handlePrevMonth}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition"
              title="Previous Month"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <select
              value={selectedMonth}
              onChange={e => setSelectedMonth(Number(e.target.value))}
              aria-label="Select Month"
              className="bg-slate-800 border border-slate-700 text-xs font-semibold text-white px-2 py-1.5 rounded-lg focus:outline-none"
            >
              {MONTH_NAMES.map((m, i) => (
                <option key={m} value={i + 1}>
                  {m}
                </option>
              ))}
            </select>
            <select
              value={selectedYear}
              onChange={e => setSelectedYear(Number(e.target.value))}
              aria-label="Select Year"
              className="bg-slate-800 border border-slate-700 text-xs font-semibold text-white px-2 py-1.5 rounded-lg focus:outline-none"
            >
              {[2025, 2026, 2027].map(y => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
            <button
              onClick={handleNextMonth}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition"
              title="Next Month"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main KPI Card with Official Formula */}
      <div className="relative overflow-hidden bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-900 border border-indigo-500/30 rounded-3xl p-5 shadow-xl">
        <div className="flex items-start justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-300 bg-indigo-500/20 px-2.5 py-0.5 rounded-full border border-indigo-500/30">
              Verified Attendance Score
            </span>
            <div className="text-4xl font-mono font-extrabold text-white mt-3">
              {stats.attendancePercentage}%
            </div>
            <p className="text-xs text-slate-300 mt-1">
              Present on <span className="text-emerald-400 font-bold">{stats.presentDays}</span> out of{' '}
              <span className="text-white font-bold">{stats.totalWorkingDays}</span> official working days
            </p>
          </div>

          <div className="w-20 h-20 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex flex-col items-center justify-center p-2 text-center">
            <TrendingUp className="w-6 h-6 text-indigo-400 mb-1" />
            <span className="text-[10px] text-indigo-300 font-bold uppercase">
              {stats.attendancePercentage >= 85 ? 'Excellent' : stats.attendancePercentage >= 75 ? 'Good' : 'Needs Focus'}
            </span>
          </div>
        </div>

        {/* Formula Explainer */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center gap-2 text-[11px] text-indigo-300/80 font-mono">
          <Info className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
          <span>Formula: (Present Days / Total Working Days) × 100</span>
        </div>
      </div>

      {/* 6 Grid Metrics */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 text-center">
          <div className="text-xs text-slate-400 flex items-center justify-center gap-1 mb-1">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span>Total Days</span>
          </div>
          <div className="text-xl font-bold font-mono text-white">{stats.totalDays}</div>
        </div>

        <div className="bg-slate-900 border border-indigo-500/20 rounded-2xl p-3 text-center">
          <div className="text-xs text-indigo-300 flex items-center justify-center gap-1 mb-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" />
            <span>Working Days</span>
          </div>
          <div className="text-xl font-bold font-mono text-indigo-300">{stats.totalWorkingDays}</div>
        </div>

        <div className="bg-slate-900 border border-emerald-500/20 rounded-2xl p-3 text-center">
          <div className="text-xs text-emerald-400 flex items-center justify-center gap-1 mb-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Present</span>
          </div>
          <div className="text-xl font-bold font-mono text-emerald-400">{stats.presentDays}</div>
        </div>

        <div className="bg-slate-900 border border-rose-500/20 rounded-2xl p-3 text-center">
          <div className="text-xs text-rose-400 flex items-center justify-center gap-1 mb-1">
            <XCircle className="w-3.5 h-3.5 text-rose-400" />
            <span>Absent</span>
          </div>
          <div className="text-xl font-bold font-mono text-rose-400">{stats.absentDays}</div>
        </div>

        <div className="bg-slate-900 border border-amber-500/20 rounded-2xl p-3 text-center">
          <div className="text-xs text-amber-400 flex items-center justify-center gap-1 mb-1">
            <ClockAlert className="w-3.5 h-3.5 text-amber-400" />
            <span>Leave</span>
          </div>
          <div className="text-xl font-bold font-mono text-amber-400">{stats.leaveDays}</div>
        </div>

        <div className="bg-slate-900 border border-purple-500/20 rounded-2xl p-3 text-center">
          <div className="text-xs text-purple-400 flex items-center justify-center gap-1 mb-1">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Holidays</span>
          </div>
          <div className="text-xl font-bold font-mono text-purple-400">{stats.holidayDays}</div>
        </div>
      </div>

      {/* Monthly Comparison Bar Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-white">Monthly Attendance Trends</h3>
            <p className="text-[11px] text-slate-400">Year {selectedYear} Comparative Graph</p>
          </div>
          <div className="text-right">
            <div className="text-xs text-slate-400">Annual Average</div>
            <div className="text-sm font-bold text-indigo-400 font-mono">{annualPercentage}%</div>
          </div>
        </div>

        {/* Visual Bar Chart */}
        <div className="space-y-2 pt-2">
          {yearMonthlyStats.map(item => {
            const isSelected = item.monthNumber === selectedMonth;
            const pct = item.stats.attendancePercentage;
            return (
              <div
                key={item.monthName}
                onClick={() => setSelectedMonth(item.monthNumber)}
                className={`p-2 rounded-xl transition cursor-pointer flex items-center gap-3 ${
                  isSelected ? 'bg-indigo-950/60 border border-indigo-500/40' : 'hover:bg-slate-800/50'
                }`}
              >
                <span className={`w-8 text-[11px] font-mono font-semibold ${isSelected ? 'text-indigo-400' : 'text-slate-400'}`}>
                  {item.shortName}
                </span>

                <div className="flex-1 bg-slate-800 rounded-full h-3 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      pct >= 80 ? 'bg-emerald-500' : pct >= 60 ? 'bg-indigo-500' : 'bg-amber-500'
                    }`}
                    style={{ width: `${Math.max(4, pct)}%` }}
                  />
                </div>

                <span className="w-12 text-right text-[11px] font-mono font-bold text-slate-300">
                  {pct}%
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Report Generation & Export Actions */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg space-y-3">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
          <Download className="w-4 h-4 text-indigo-400" />
          Export Reports &amp; Summaries
        </h3>
        <p className="text-[11px] text-slate-400">
          Generate formal attendance reports for school submissions, guardian reviews, or personal archives.
        </p>

        <div className="grid grid-cols-3 gap-2 pt-1">
          <button
            onClick={() => exportToCSV(records)}
            className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>CSV File</span>
          </button>

          <button
            onClick={() => exportToJSON(records, profile, holidays, workingDays)}
            className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>JSON Backup</span>
          </button>

          <button
            onClick={handlePrintPDF}
            className="py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white shadow-md shadow-indigo-600/30 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / PDF</span>
          </button>
        </div>
      </div>
    </div>
  );
};
