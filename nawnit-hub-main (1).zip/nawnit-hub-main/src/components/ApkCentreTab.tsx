import React, { useState } from 'react';
import {
  Download,
  Search,
  CheckCircle2,
  Clock,
  ShieldCheck,
  ShieldAlert,
  Trash2,
  RefreshCw,
  PlusCircle,
  ExternalLink,
  Package,
  FileCode,
  HardDrive,
  Info,
  X
} from 'lucide-react';
import { ApkItem, DownloadTask } from '../types';
import { formatBytes } from '../utils/crypto';
import confetti from 'canvas-confetti';

interface ApkCentreTabProps {
  apkCatalog: ApkItem[];
  downloadTasks: DownloadTask[];
  onStartDownload: (apk: ApkItem) => void;
  onRetryDownload: (taskId: string) => void;
  onRemoveDownloadedFile: (taskId: string) => void;
  onAddApkEntry: (apk: ApkItem) => void;
}

export const ApkCentreTab: React.FC<ApkCentreTabProps> = ({
  apkCatalog,
  downloadTasks,
  onStartDownload,
  onRetryDownload,
  onRemoveDownloadedFile,
  onAddApkEntry
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<'catalog' | 'history'>('catalog');
  
  // Security warning & Package Installer modal
  const [installModalApk, setInstallModalApk] = useState<{ apk: ApkItem; task: DownloadTask } | null>(null);
  const [isVerifyingHash, setIsVerifyingHash] = useState<boolean>(false);
  const [verifiedHashSuccess, setVerifiedHashSuccess] = useState<boolean | null>(null);

  // Admin Add APK Modal
  const [showAdminAddModal, setShowAdminAddModal] = useState<boolean>(false);
  const [newApkName, setNewApkName] = useState('');
  const [newPackageName, setNewPackageName] = useState('com.student.');
  const [newVersion, setNewVersion] = useState('1.0.0');
  const [newSizeMb, setNewSizeMb] = useState('15.5');
  const [newCategory, setNewCategory] = useState<ApkItem['category']>('Productivity');
  const [newDescription, setNewDescription] = useState('');
  const [newDownloadUrl, setNewDownloadUrl] = useState('https://trusted-mirror.studenthub.np/apks/');
  const [newSha256, setNewSha256] = useState('');
  const [newDeveloper, setNewDeveloper] = useState('Nawnit Pandey');
  const [newSourceUrl, setNewSourceUrl] = useState('https://github.com/nawnithub');

  const categories = ['All', 'Official', 'Education', 'Productivity', 'Tools'];

  const filteredCatalog = apkCatalog.filter(apk => {
    const matchesSearch =
      apk.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      apk.packageName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      apk.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'All' || apk.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const getTaskForApk = (apkId: string): DownloadTask | undefined => {
    return downloadTasks.find(t => t.apkId === apkId);
  };

  const handleOpenInstallConfirmation = (apk: ApkItem, task: DownloadTask) => {
    setInstallModalApk({ apk, task });
    setIsVerifyingHash(true);
    setVerifiedHashSuccess(null);

    // Simulate cryptographic SHA-256 integrity verification
    setTimeout(() => {
      setIsVerifyingHash(false);
      setVerifiedHashSuccess(true);
    }, 800);
  };

  const handleConfirmPackageInstaller = () => {
    try {
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }
    alert(
      `[Android PackageInstaller Flow]\n\nPrompting standard Android system package installer for "${installModalApk?.apk.name}" (${installModalApk?.apk.packageName}).\n\nSecurity Status: SHA-256 integrity verified.\nSource: Trusted Nawnit Hub Mirror.\n\nUser authorization required by Google Play Protect.`
    );
    setInstallModalApk(null);
  };

  const handleCreateNewApk = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newApkName.trim()) return;

    const newApk: ApkItem = {
      id: `apk-${Date.now()}`,
      name: newApkName.trim(),
      packageName: newPackageName.trim() || `com.nawnit.${newApkName.toLowerCase().replace(/\s+/g, '')}`,
      version: newVersion.trim() || '1.0.0',
      versionCode: 1,
      fileSizeMb: parseFloat(newSizeMb) || 12.0,
      iconUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=120&q=80',
      description: newDescription.trim() || 'Student utility application verified for Nawnit Hub.',
      category: newCategory,
      downloadUrl: newDownloadUrl.trim(),
      sha256: newSha256.trim() || 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      developer: newDeveloper.trim() || 'Nawnit Hub Community',
      officialSourceUrl: newSourceUrl.trim() || 'https://github.com/nawnithub',
      minSdkVersion: 26,
      targetSdkVersion: 35,
      releaseDate: 'October 2026',
      downloadCount: 1
    };

    onAddApkEntry(newApk);
    setShowAdminAddModal(false);
    // Reset form
    setNewApkName('');
    setNewDescription('');
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/50 to-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-[11px] font-bold text-indigo-400 uppercase tracking-wide">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Verified APK Repository
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">APK Download Centre</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Secure Android package distribution with SHA-256 integrity verification
            </p>
          </div>
          <button
            onClick={() => setShowAdminAddModal(true)}
            className="flex items-center gap-1 px-3 py-2 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 rounded-xl text-xs font-semibold transition active:scale-95"
            title="Add APK to Repository (Admin)"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add APK</span>
          </button>
        </div>

        {/* View Switcher: Catalog vs Download History */}
        <div className="flex gap-2 mt-4 pt-3 border-t border-slate-800">
          <button
            onClick={() => setActiveTab('catalog')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-semibold transition ${
              activeTab === 'catalog'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'bg-slate-800/80 text-slate-400 hover:text-white'
            }`}
          >
            Available Apps ({apkCatalog.length})
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-1.5 px-3 rounded-xl text-xs font-semibold transition ${
              activeTab === 'history'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'bg-slate-800/80 text-slate-400 hover:text-white'
            }`}
          >
            Download History ({downloadTasks.length})
          </button>
        </div>
      </div>

      {activeTab === 'catalog' && (
        <>
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search apps by name, package or keywords..."
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Category Filter Pills */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`shrink-0 px-3 py-1 rounded-full text-xs font-medium transition ${
                  selectedCategory === cat
                    ? 'bg-indigo-500 text-white shadow-sm'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* App Cards List */}
          <div className="space-y-3">
            {filteredCatalog.length === 0 ? (
              <div className="text-center py-12 bg-slate-900 rounded-3xl border border-slate-800 p-6">
                <Package className="w-10 h-10 mx-auto text-slate-600 mb-2" />
                <h4 className="text-sm font-semibold text-slate-300">No Applications Found</h4>
                <p className="text-xs text-slate-500 mt-1">Try searching with different terms or categories.</p>
              </div>
            ) : (
              filteredCatalog.map(apk => {
                const task = getTaskForApk(apk.id);
                const isDownloading = task?.status === 'DOWNLOADING';
                const isCompleted = task?.status === 'COMPLETED';

                return (
                  <div
                    key={apk.id}
                    className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-md space-y-3"
                  >
                    <div className="flex items-start gap-3">
                      <img
                        src={apk.iconUrl}
                        alt={apk.name}
                        className="w-12 h-12 rounded-2xl object-cover ring-1 ring-slate-700 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <h3 className="text-sm font-bold text-white truncate">{apk.name}</h3>
                          {apk.category === 'Official' && (
                            <span className="shrink-0 px-1.5 py-0.5 rounded text-[9px] font-bold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                              OFFICIAL
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 font-mono truncate">{apk.packageName}</p>
                        <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400">
                          <span className="text-indigo-400 font-semibold">v{apk.version}</span>
                          <span>•</span>
                          <span className="flex items-center gap-0.5">
                            <HardDrive className="w-3 h-3 text-slate-500" />
                            {apk.fileSizeMb} MB
                          </span>
                          <span>•</span>
                          <span>{apk.developer}</span>
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed">{apk.description}</p>

                    {/* SHA-256 Badge */}
                    <div className="flex items-center gap-1.5 p-2 rounded-xl bg-slate-950/80 border border-slate-800 text-[10px] font-mono text-slate-400">
                      <FileCode className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      <span className="truncate">SHA-256: {apk.sha256}</span>
                    </div>

                    {/* Download Progress Bar if active */}
                    {isDownloading && task && (
                      <div className="space-y-1.5 pt-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-indigo-400 font-medium flex items-center gap-1">
                            <RefreshCw className="w-3 h-3 animate-spin" />
                            Downloading ({task.downloadSpeed})
                          </span>
                          <span className="font-mono text-white font-bold">{task.progress}%</span>
                        </div>
                        <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all duration-300"
                            style={{ width: `${task.progress}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                          <span>{formatBytes(task.downloadedBytes)}</span>
                          <span>{formatBytes(task.totalBytes)}</span>
                        </div>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                      <a
                        href={apk.officialSourceUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                      >
                        <span>Official Source</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>

                      {isCompleted && task ? (
                        <button
                          onClick={() => handleOpenInstallConfirmation(apk, task)}
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-emerald-600/30 active:scale-95 transition"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Install APK</span>
                        </button>
                      ) : isDownloading ? (
                        <button
                          disabled
                          className="px-4 py-2 bg-indigo-600/50 text-indigo-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-not-allowed"
                        >
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Downloading...</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => onStartDownload(apk)}
                          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-indigo-600/30 active:scale-95 transition"
                        >
                          <Download className="w-4 h-4" />
                          <span>Download ({apk.fileSizeMb} MB)</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </>
      )}

      {/* History Tab */}
      {activeTab === 'history' && (
        <div className="space-y-3">
          {downloadTasks.length === 0 ? (
            <div className="text-center py-12 bg-slate-900 rounded-3xl border border-slate-800 p-6">
              <Download className="w-10 h-10 mx-auto text-slate-600 mb-2" />
              <h4 className="text-sm font-semibold text-slate-300">No Download History</h4>
              <p className="text-xs text-slate-500 mt-1">APKs you download will appear here.</p>
            </div>
          ) : (
            downloadTasks.map(task => {
              const apk = apkCatalog.find(a => a.id === task.apkId);
              return (
                <div
                  key={task.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 shadow-md space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white truncate">{task.apkName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {task.fileName} • {formatBytes(task.totalBytes)}
                      </div>
                    </div>
                    {task.status === 'COMPLETED' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Completed
                      </span>
                    ) : task.status === 'FAILED' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-500/15 text-rose-400 border border-rose-500/30 flex items-center gap-1">
                        Failed
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/15 text-indigo-400 border border-indigo-500/30 flex items-center gap-1">
                        <Clock className="w-3 h-3 animate-spin" /> In Progress
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                    <span className="text-[10px] text-slate-500">
                      {new Date(task.startTime).toLocaleTimeString()}
                    </span>

                    <div className="flex items-center gap-1.5">
                      {task.status === 'FAILED' && (
                        <button
                          onClick={() => onRetryDownload(task.id)}
                          className="px-2.5 py-1 rounded-lg bg-indigo-600/20 text-indigo-300 hover:bg-indigo-600/30 text-xs font-semibold flex items-center gap-1"
                        >
                          <RefreshCw className="w-3 h-3" />
                          <span>Retry</span>
                        </button>
                      )}
                      {task.status === 'COMPLETED' && apk && (
                        <button
                          onClick={() => handleOpenInstallConfirmation(apk, task)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600/20 text-emerald-300 hover:bg-emerald-600/30 text-xs font-semibold flex items-center gap-1"
                        >
                          <Package className="w-3 h-3" />
                          <span>Install</span>
                        </button>
                      )}
                      <button
                        onClick={() => onRemoveDownloadedFile(task.id)}
                        className="p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition"
                        title="Remove from device"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* PackageInstaller Security Flow Modal */}
      {installModalApk && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4">
          <div className="relative w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl space-y-4">
            <button
              onClick={() => setInstallModalApk(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1.5 rounded-full hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-12 h-12 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mx-auto">
              <Package className="w-6 h-6" />
            </div>

            <div className="text-center">
              <h3 className="text-base font-bold text-white">Android Package Installer</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Install <span className="text-indigo-400 font-semibold">{installModalApk.apk.name}</span> v{installModalApk.apk.version}
              </p>
            </div>

            {/* Cryptographic SHA-256 verification box */}
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-medium">Integrity Check</span>
                {isVerifyingHash ? (
                  <span className="text-indigo-400 font-mono flex items-center gap-1">
                    <RefreshCw className="w-3 h-3 animate-spin" /> Verifying SHA-256...
                  </span>
                ) : verifiedHashSuccess ? (
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> Hash Verified
                  </span>
                ) : (
                  <span className="text-rose-400 font-semibold">Verification Error</span>
                )}
              </div>
              <div className="text-[10px] font-mono text-slate-500 break-all bg-slate-900 p-1.5 rounded-lg">
                {installModalApk.apk.sha256}
              </div>
            </div>

            {/* Security Warning Notice as per guidelines */}
            <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
              <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
              <div className="text-[11px] leading-relaxed">
                <span className="font-bold">Play Protect Security Notice:</span> Installation uses Android's official PackageInstaller flow. Android will request permission to install unknown apps from this source.
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setInstallModalApk(null)}
                className="flex-1 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isVerifyingHash}
                onClick={handleConfirmPackageInstaller}
                className="flex-1 py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-600/30 transition disabled:opacity-50"
              >
                Confirm &amp; Install
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Add APK Modal */}
      {showAdminAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 overflow-y-auto">
          <form
            onSubmit={handleCreateNewApk}
            className="relative w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl space-y-3.5 my-8"
          >
            <button
              type="button"
              onClick={() => setShowAdminAddModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1.5 rounded-full hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                <PlusCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Add APK Entry (Admin)</h3>
                <p className="text-xs text-slate-400">Add a verified student tool to the APK Centre</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-300">App Name *</label>
                <input
                  type="text"
                  required
                  value={newApkName}
                  onChange={e => setNewApkName(e.target.value)}
                  placeholder="e.g. NCERT Chemistry Lab"
                  className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300">Package Name *</label>
                <input
                  type="text"
                  required
                  value={newPackageName}
                  onChange={e => setNewPackageName(e.target.value)}
                  placeholder="com.nawnit.app"
                  className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2.5">
              <div>
                <label className="text-xs font-semibold text-slate-300">Version</label>
                <input
                  type="text"
                  value={newVersion}
                  onChange={e => setNewVersion(e.target.value)}
                  placeholder="1.0.0"
                  className="w-full mt-1 px-2.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300">Size (MB)</label>
                <input
                  type="number"
                  step="0.1"
                  value={newSizeMb}
                  onChange={e => setNewSizeMb(e.target.value)}
                  placeholder="14.5"
                  className="w-full mt-1 px-2.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300">Category</label>
                <select
                  value={newCategory}
                  onChange={e => setNewCategory(e.target.value as any)}
                  className="w-full mt-1 px-2 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="Education">Education</option>
                  <option value="Productivity">Productivity</option>
                  <option value="Tools">Tools</option>
                  <option value="Official">Official</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300">Description</label>
              <textarea
                rows={2}
                value={newDescription}
                onChange={e => setNewDescription(e.target.value)}
                placeholder="Brief summary of features, target audience, and permissions..."
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300">APK Download URL</label>
              <input
                type="url"
                required
                value={newDownloadUrl}
                onChange={e => setNewDownloadUrl(e.target.value)}
                placeholder="https://..."
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300">SHA-256 Checksum (Optional)</label>
              <input
                type="text"
                value={newSha256}
                onChange={e => setNewSha256(e.target.value)}
                placeholder="64-character hex string for file integrity check"
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-300">Developer</label>
                <input
                  type="text"
                  value={newDeveloper}
                  onChange={e => setNewDeveloper(e.target.value)}
                  placeholder="Author or Org"
                  className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300">Official Link</label>
                <input
                  type="url"
                  value={newSourceUrl}
                  onChange={e => setNewSourceUrl(e.target.value)}
                  placeholder="https://github.com/..."
                  className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowAdminAddModal(false)}
                className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="py-2.5 px-5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-600/30 transition"
              >
                Save APK to Catalog
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
