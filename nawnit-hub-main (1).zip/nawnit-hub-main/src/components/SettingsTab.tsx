import React, { useState } from 'react';
import {
  User,
  Shield,
  Calendar,
  Bell,
  HardDrive,
  Trash2,
  Lock,
  Fingerprint,
  Save,
  Plus,
  Smartphone,
  ChevronRight,
  Upload,
  Download,
  Camera,
  MapPin,
  Clock,
  Sparkles
} from 'lucide-react';
import {
  UserProfile,
  WorkingDaysConfig,
  HolidayItem,
  SecuritySettings,
  AppReminder,
  AttendanceRecord
} from '../types';
import { exportToJSON, exportToCSV, clearAllData } from '../utils/storage';
import { ProfileEditView } from './ProfileEditView';
import { ImportDataModal } from './ImportDataModal';

interface SettingsTabProps {
  profile: UserProfile;
  workingDays: WorkingDaysConfig;
  holidays: HolidayItem[];
  securitySettings: SecuritySettings;
  reminders: AppReminder[];
  records: Record<string, AttendanceRecord>;
  onUpdateProfile: (profile: UserProfile) => void;
  onUpdateWorkingDays: (config: WorkingDaysConfig) => void;
  onUpdateHolidays: (holidays: HolidayItem[]) => void;
  onUpdateSecurity: (settings: SecuritySettings) => void;
  onToggleReminder: (reminderId: string) => void;
  onRequestPinSetup: () => void;
  onLockNow: () => void;
  onRestoreData: (records: Record<string, AttendanceRecord>, profile: UserProfile) => void;
  onOpenAndroidStudio: () => void;
  initialIndex?: 'index' | 'profile';
}

export const SettingsTab: React.FC<SettingsTabProps> = ({
  profile,
  workingDays,
  holidays,
  securitySettings,
  reminders,
  records,
  onUpdateProfile,
  onUpdateWorkingDays,
  onUpdateHolidays,
  onUpdateSecurity,
  onToggleReminder,
  onRequestPinSetup,
  onLockNow,
  onRestoreData,
  onOpenAndroidStudio,
  initialIndex = 'index'
}) => {
  // Navigation inside Settings: 'index' (main menu) or 'profile' (separate index for profile update)
  const [activeSettingsView, setActiveSettingsView] = useState<'index' | 'profile'>(initialIndex);

  // Import Data Modal State
  const [showImportModal, setShowImportModal] = useState<boolean>(false);

  // Holiday add state
  const [newHolidayName, setNewHolidayName] = useState('');
  const [newHolidayDate, setNewHolidayDate] = useState('');

  // Clear data confirm modal
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // If in separate Profile Index, render ProfileEditView directly
  if (activeSettingsView === 'profile') {
    return (
      <ProfileEditView
        profile={profile}
        onSaveProfile={newProf => {
          onUpdateProfile(newProf);
        }}
        onBack={() => setActiveSettingsView('index')}
      />
    );
  }

  const handleToggleWorkDay = (dayKey: keyof WorkingDaysConfig) => {
    onUpdateWorkingDays({
      ...workingDays,
      [dayKey]: !workingDays[dayKey]
    });
  };

  const handleAddHoliday = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHolidayName.trim() || !newHolidayDate) return;
    const newHol: HolidayItem = {
      id: `hol-${Date.now()}`,
      name: newHolidayName.trim(),
      date: newHolidayDate
    };
    onUpdateHolidays([...holidays, newHol]);
    setNewHolidayName('');
    setNewHolidayDate('');
  };

  const handleRemoveHoliday = (id: string) => {
    onUpdateHolidays(holidays.filter(h => h.id !== id));
  };

  const handleImportSuccess = ({
    records: importedRecords,
    profile: importedProfile,
    holidays: importedHolidays,
    workingDays: importedWorkingDays,
    mode
  }: {
    records: Record<string, AttendanceRecord>;
    profile?: UserProfile;
    holidays?: HolidayItem[];
    workingDays?: WorkingDaysConfig;
    mode: 'merge' | 'replace';
  }) => {
    const nextRecords =
      mode === 'merge' ? { ...records, ...importedRecords } : importedRecords;

    const nextProfile = importedProfile ? { ...profile, ...importedProfile } : profile;

    onRestoreData(nextRecords, nextProfile);

    if (importedHolidays && importedHolidays.length > 0) {
      onUpdateHolidays(
        mode === 'merge'
          ? [
              ...holidays,
              ...importedHolidays.filter(ih => !holidays.some(h => h.id === ih.id))
            ]
          : importedHolidays
      );
    }

    if (importedWorkingDays) {
      onUpdateWorkingDays(importedWorkingDays);
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Settings Index Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg">
        <h2 className="text-xl font-bold text-white tracking-tight">Settings &amp; Preferences</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Student profile, security PIN, working calendar and data import/export
        </p>
      </div>

      {/* Profile Overview Card (Separate Settings Index Entry) */}
      <div
        onClick={() => setActiveSettingsView('profile')}
        className="group relative overflow-hidden bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/30 hover:border-indigo-500/60 rounded-3xl p-4 sm:p-5 shadow-lg cursor-pointer transition active:scale-98"
      >
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3.5 min-w-0">
            <div className="relative shrink-0">
              <img
                src={profile.avatarUrl}
                alt={profile.name}
                className="w-14 h-14 rounded-2xl object-cover ring-2 ring-indigo-500/50 shadow-md"
              />
              <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-indigo-600 ring-2 ring-slate-900 flex items-center justify-center text-white">
                <Camera className="w-2.5 h-2.5" />
              </span>
            </div>

            <div className="min-w-0">
              <div className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1">
                <span>Separate Profile Index</span>
                <span>&bull;</span>
                <span className="text-emerald-400">Class {profile.studentClass}</span>
              </div>
              <h3 className="text-base font-bold text-white truncate">{profile.name}</h3>
              <p className="text-xs text-slate-400 truncate">
                Roll #{profile.rollNumber} &bull; {profile.schoolName}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0 px-3 py-1.5 rounded-xl bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 group-hover:bg-indigo-600 group-hover:text-white transition text-xs font-semibold">
            <span>Edit Profile</span>
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* Section: Data Storage, Import & Export */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HardDrive className="w-5 h-5 text-indigo-400" />
            <div>
              <h3 className="text-sm font-bold text-white">Data Management &amp; Persistence</h3>
              <p className="text-[10px] text-slate-400">Offline SQLite Room database &amp; backup engine</p>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            {Object.keys(records).length} Records
          </span>
        </div>

        {/* Action Grid: Import Data & Export Data */}
        <div className="grid grid-cols-2 gap-2.5 pt-1">
          {/* Dedicated Import Data Button */}
          <button
            type="button"
            onClick={() => setShowImportModal(true)}
            className="py-3 px-3 rounded-2xl bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 active:scale-95 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/25 transition"
          >
            <Upload className="w-4 h-4" />
            <span>Import Data</span>
          </button>

          {/* Export JSON Backup */}
          <button
            type="button"
            onClick={() => exportToJSON(records, profile, holidays, workingDays)}
            className="py-3 px-3 rounded-2xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 border border-slate-700 text-xs font-bold flex items-center justify-center gap-2 transition"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Export Backup</span>
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
          <button
            type="button"
            onClick={() => exportToCSV(records)}
            className="py-2 px-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 flex items-center justify-center gap-1.5 transition"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>Download CSV</span>
          </button>

          <button
            type="button"
            onClick={() => setShowClearConfirm(true)}
            className="py-2 px-3 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 flex items-center justify-center gap-1.5 transition"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Reset Database</span>
          </button>
        </div>
      </div>

      {/* Section: App Lock & Security */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-indigo-400" />
            <div>
              <h3 className="text-sm font-bold text-white">App Lock &amp; Privacy</h3>
              <p className="text-[10px] text-slate-400">Android Keystore AES-256 GCM encrypted PIN</p>
            </div>
          </div>
          <button
            onClick={onLockNow}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-slate-300 hover:text-rose-400 border border-slate-700 text-xs font-semibold flex items-center gap-1 transition active:scale-95"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Lock Now</span>
          </button>
        </div>

        {/* PIN Setup / Change */}
        <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
          <div>
            <div className="text-xs font-semibold text-white">PIN Protection</div>
            <div className="text-[10px] text-slate-400">
              {securitySettings.isPinEnabled ? 'PIN lock is active' : 'PIN lock is currently disabled'}
            </div>
          </div>
          <button
            onClick={onRequestPinSetup}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition active:scale-95 ${
              securitySettings.isPinEnabled
                ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
                : 'bg-indigo-600 text-white shadow-md'
            }`}
          >
            {securitySettings.isPinEnabled ? 'Change PIN' : 'Set Up PIN'}
          </button>
        </div>

        {/* Biometrics */}
        <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
          <div className="flex items-center gap-2.5">
            <Fingerprint className="w-5 h-5 text-indigo-400" />
            <div>
              <div className="text-xs font-semibold text-white">Biometric Sensor</div>
              <div className="text-[10px] text-slate-400">Fingerprint authentication support</div>
            </div>
          </div>
          <button
            onClick={() =>
              onUpdateSecurity({
                ...securitySettings,
                isBiometricEnabled: !securitySettings.isBiometricEnabled
              })
            }
            className={`w-10 h-5 rounded-full transition-colors relative flex items-center p-0.5 ${
              securitySettings.isBiometricEnabled ? 'bg-indigo-600' : 'bg-slate-800'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform ${
                securitySettings.isBiometricEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Auto Lock Duration */}
        <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
          <div>
            <div className="text-xs font-semibold text-white">Inactivity Auto-Lock</div>
            <div className="text-[10px] text-slate-400">Locks application after idle time</div>
          </div>
          <select
            value={securitySettings.autoLockTimeoutMinutes}
            onChange={e =>
              onUpdateSecurity({
                ...securitySettings,
                autoLockTimeoutMinutes: Number(e.target.value)
              })
            }
            aria-label="Inactivity Auto-Lock Duration"
            className="bg-slate-800 border border-slate-700 text-xs font-semibold text-white px-2 py-1 rounded-lg focus:outline-none"
          >
            <option value={0}>Immediately</option>
            <option value={1}>1 Minute</option>
            <option value={5}>5 Minutes</option>
            <option value={15}>15 Minutes</option>
            <option value={-1}>Never</option>
          </select>
        </div>
      </div>

      {/* Section: Working Days & Holiday Calendar */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-4">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-indigo-400" />
          <div>
            <h3 className="text-sm font-bold text-white">Working Days &amp; Calendar</h3>
            <p className="text-[10px] text-slate-400">Configures attendance percentage denominator</p>
          </div>
        </div>

        {/* Working Days Checkboxes */}
        <div>
          <label className="text-xs font-semibold text-slate-300 mb-2 block">Weekly Working Days</label>
          <div className="grid grid-cols-7 gap-1">
            {(
              [
                ['sun', 'sunday', 'Sun'],
                ['mon', 'monday', 'Mon'],
                ['tue', 'tuesday', 'Tue'],
                ['wed', 'wednesday', 'Wed'],
                ['thu', 'thursday', 'Thu'],
                ['fri', 'friday', 'Fri'],
                ['sat', 'saturday', 'Sat']
              ] as const
            ).map(([abbr, fullKey, label]) => {
              const isActive = workingDays[fullKey];
              return (
                <button
                  key={abbr}
                  type="button"
                  onClick={() => handleToggleWorkDay(fullKey)}
                  className={`py-2 rounded-xl text-xs font-semibold border flex flex-col items-center justify-center transition active:scale-95 ${
                    isActive
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm'
                      : 'bg-slate-950 text-slate-500 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <span>{label}</span>
                  <span className="text-[9px] opacity-75">{isActive ? 'ON' : 'OFF'}</span>
                </button>
              );
            })}
          </div>
          <p className="text-[10px] text-slate-500 mt-1.5">
            Note: In Nepal, Saturday is the standard weekly weekend/holiday.
          </p>
        </div>

        {/* Holidays List */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-slate-300">
              Registered Holidays ({holidays.length})
            </label>
          </div>

          <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
            {holidays.map(h => (
              <div
                key={h.id}
                className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800 text-xs"
              >
                <div>
                  <span className="font-semibold text-white">{h.name}</span>
                  <span className="text-[10px] font-mono text-indigo-400 ml-2">{h.date}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleRemoveHoliday(h.id)}
                  className="p-1 text-slate-500 hover:text-rose-400 transition"
                  title="Remove holiday"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          {/* Add Custom Holiday */}
          <form onSubmit={handleAddHoliday} className="flex gap-2 pt-1">
            <input
              type="date"
              required
              value={newHolidayDate}
              onChange={e => setNewHolidayDate(e.target.value)}
              className="px-2 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
            />
            <input
              type="text"
              required
              placeholder="Holiday name (e.g. Sports Day)"
              value={newHolidayName}
              onChange={e => setNewHolidayName(e.target.value)}
              className="flex-1 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shrink-0"
            >
              <Plus className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      {/* Section: Android Studio Project & About */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-indigo-400" />
            <div>
              <h3 className="text-sm font-bold text-white">Nawnit Hub v1.2.0</h3>
              <p className="text-[10px] text-slate-400">Android 15 &bull; Jetpack Compose &bull; Room SQLite</p>
            </div>
          </div>
          <button
            onClick={onOpenAndroidStudio}
            className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold transition active:scale-95 shadow-md shadow-indigo-600/30"
          >
            Source Code (.zip)
          </button>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          Nawnit Hub is engineered with Kotlin and Jetpack Compose for low memory consumption, high efficiency on low-RAM devices, and offline-first student productivity.
        </p>
      </div>

      {/* Import Data Modal */}
      {showImportModal && (
        <ImportDataModal
          onClose={() => setShowImportModal(false)}
          onImportSuccess={handleImportSuccess}
          currentRecordsCount={Object.keys(records).length}
        />
      )}

      {/* Destructive Clear Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center">
              <h3 className="text-base font-bold text-white">Reset Application Data?</h3>
              <p className="text-xs text-slate-400 mt-1">
                This will delete all saved attendance records, custom holidays, and user preferences.
              </p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  clearAllData();
                  window.location.reload();
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold shadow-md shadow-rose-600/30"
              >
                Yes, Reset All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
