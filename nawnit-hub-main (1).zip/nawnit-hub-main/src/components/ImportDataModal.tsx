import React, { useState, useRef } from 'react';
import {
  Upload,
  FileText,
  FileJson,
  CheckCircle2,
  AlertCircle,
  X,
  Database,
  ArrowRight
} from 'lucide-react';
import { AttendanceRecord, UserProfile, HolidayItem, WorkingDaysConfig } from '../types';
import { parseImportJSON, parseImportCSV, ImportResult } from '../utils/storage';
import confetti from 'canvas-confetti';

interface ImportDataModalProps {
  onClose: () => void;
  onImportSuccess: (data: {
    records: Record<string, AttendanceRecord>;
    profile?: UserProfile;
    holidays?: HolidayItem[];
    workingDays?: WorkingDaysConfig;
    mode: 'merge' | 'replace';
  }) => void;
  currentRecordsCount: number;
}

export const ImportDataModal: React.FC<ImportDataModalProps> = ({
  onClose,
  onImportSuccess,
  currentRecordsCount
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    processSelectedFile(selected);
  };

  const processSelectedFile = (selected: File) => {
    setFile(selected);
    setErrorMsg('');
    setIsProcessing(true);

    const reader = new FileReader();
    reader.onload = event => {
      const text = event.target?.result as string;
      const lowerName = selected.name.toLowerCase();

      let result: ImportResult;
      if (lowerName.endsWith('.csv')) {
        result = parseImportCSV(text);
      } else {
        result = parseImportJSON(text);
      }

      setIsProcessing(false);
      setImportResult(result);
      if (!result.success) {
        setErrorMsg(result.message);
      }
    };

    reader.onerror = () => {
      setIsProcessing(false);
      setErrorMsg('Failed to read selected file.');
    };

    reader.readAsText(selected);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processSelectedFile(e.dataTransfer.files[0]);
    }
  };

  const handleConfirmImport = () => {
    if (!importResult || !importResult.success || !importResult.attendanceRecords) return;

    onImportSuccess({
      records: importResult.attendanceRecords,
      profile: importResult.userProfile,
      holidays: importResult.holidays,
      workingDays: importResult.workingDays,
      mode: importMode
    });

    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4">
      <div className="relative w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 p-5 sm:p-6 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Import Data</h3>
              <p className="text-xs text-slate-400">Restore JSON backup or import CSV attendance</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Dropzone Area */}
        <div
          onDragOver={e => e.preventDefault()}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-slate-700 hover:border-indigo-500 bg-slate-950/60 hover:bg-slate-950 rounded-2xl p-6 text-center cursor-pointer transition space-y-2 group"
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".json,.csv"
            onChange={handleFileChange}
            className="hidden"
          />
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 group-hover:bg-indigo-500/20 text-indigo-400 mx-auto flex items-center justify-center transition">
            <Upload className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-semibold text-slate-200">
              {file ? file.name : 'Click to browse or drop file here'}
            </span>
            <p className="text-[10px] text-slate-500 mt-0.5">
              Supports .json (Full Backup) or .csv (Attendance History)
            </p>
          </div>
        </div>

        {/* Processing State */}
        {isProcessing && (
          <div className="text-center py-2 text-xs text-indigo-400 font-medium animate-pulse">
            Parsing file contents...
          </div>
        )}

        {/* Error message */}
        {errorMsg && (
          <div className="flex items-start gap-2 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-300">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Preview of Parsed Data */}
        {importResult && importResult.success && (
          <div className="space-y-3 p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
            <div className="flex items-center justify-between text-xs">
              <span className="text-emerald-400 font-semibold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> Ready to Import
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                {importResult.count} records
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                <div className="text-slate-400 flex items-center gap-1">
                  <FileText className="w-3 h-3 text-indigo-400" /> File Type
                </div>
                <div className="text-white font-bold mt-0.5">
                  {file?.name.toLowerCase().endsWith('.csv') ? 'CSV Attendance' : 'JSON Backup'}
                </div>
              </div>

              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                <div className="text-slate-400 flex items-center gap-1">
                  <Database className="w-3 h-3 text-emerald-400" /> Profile Included
                </div>
                <div className="text-white font-bold mt-0.5">
                  {importResult.userProfile ? importResult.userProfile.name : 'No (records only)'}
                </div>
              </div>
            </div>

            {/* Import Mode Selection */}
            <div className="space-y-1.5 pt-1">
              <label className="text-[11px] font-semibold text-slate-300">Import Strategy</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setImportMode('merge')}
                  className={`py-2 px-2.5 rounded-xl text-xs font-semibold border transition text-left ${
                    importMode === 'merge'
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold">Merge Records</div>
                  <div className="text-[10px] opacity-80 mt-0.5 font-normal">
                    Keep existing ({currentRecordsCount}) &amp; add new
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setImportMode('replace')}
                  className={`py-2 px-2.5 rounded-xl text-xs font-semibold border transition text-left ${
                    importMode === 'replace'
                      ? 'bg-rose-600 text-white border-rose-500 shadow-sm'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold">Replace All</div>
                  <div className="text-[10px] opacity-80 mt-0.5 font-normal">
                    Overwrite existing records
                  </div>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center gap-2 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!importResult || !importResult.success}
            onClick={handleConfirmImport}
            className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-semibold shadow-lg shadow-indigo-600/30 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1.5"
          >
            <span>Confirm Import</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
