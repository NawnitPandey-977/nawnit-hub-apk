import React, { useState, useRef } from 'react';
import {
  ArrowLeft,
  Camera,
  Upload,
  Save,
  CheckCircle2,
  Sparkles,
  RotateCcw,
  User,
  GraduationCap,
  MapPin,
  Clock,
  School,
  Hash
} from 'lucide-react';
import { UserProfile } from '../types';
import { DEFAULT_USER_PROFILE } from '../data/initialData';
import confetti from 'canvas-confetti';

interface ProfileEditViewProps {
  profile: UserProfile;
  onSaveProfile: (profile: UserProfile) => void;
  onBack: () => void;
}

const PRESET_AVATARS = [
  {
    name: 'Student Default',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Scholar Boy',
    url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Science Student',
    url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Smart Learner',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80'
  },
  {
    name: 'Campus High School',
    url: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?auto=format&fit=crop&w=400&q=80'
  }
];

export const ProfileEditView: React.FC<ProfileEditViewProps> = ({
  profile,
  onSaveProfile,
  onBack
}) => {
  const [name, setName] = useState(profile.name);
  const [studentClass, setStudentClass] = useState(profile.studentClass);
  const [country, setCountry] = useState(profile.country);
  const [timeZone] = useState(profile.timeZone);
  const [rollNumber, setRollNumber] = useState(profile.rollNumber);
  const [schoolName, setSchoolName] = useState(profile.schoolName);
  const [academicYear, setAcademicYear] = useState(profile.academicYear);
  const [avatarUrl, setAvatarUrl] = useState(profile.avatarUrl);
  const [photoSourceNote, setPhotoSourceNote] = useState<string>('');
  const [isSaved, setIsSaved] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // File Upload Handler: Converts uploaded image file to Data URL
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate type
    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file (PNG, JPG, WebP, etc.)');
      return;
    }

    // Limit to reasonable size (< 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('Photo size exceeds 5MB. Please choose a smaller picture.');
      return;
    }

    const reader = new FileReader();
    reader.onload = event => {
      const result = event.target?.result as string;
      setAvatarUrl(result);
      setPhotoSourceNote(`Uploaded: ${file.name} (${Math.round(file.size / 1024)} KB)`);
    };
    reader.readAsDataURL(file);
  };

  const handleResetToDefaultPhoto = () => {
    setAvatarUrl(DEFAULT_USER_PROFILE.avatarUrl);
    setPhotoSourceNote('Reset to default photo');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      ...profile,
      name: name.trim() || 'Nawnit Pandey',
      studentClass: studentClass.trim() || '9',
      country: country.trim() || 'Nepal',
      timeZone: timeZone || 'Asia/Kathmandu',
      rollNumber: rollNumber.trim() || '09',
      schoolName: schoolName.trim() || 'Kathmandu Model Academy',
      academicYear: academicYear.trim() || '2026-2027 AD (2083 BS)',
      avatarUrl: avatarUrl.trim() || DEFAULT_USER_PROFILE.avatarUrl
    };

    onSaveProfile(updated);
    setIsSaved(true);

    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }

    setTimeout(() => {
      setIsSaved(false);
    }, 2500);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Top Header with Back Button */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition active:scale-95"
            title="Back to Settings Index"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider">
              Settings &bull; Profile Index
            </div>
            <h2 className="text-lg font-bold text-white tracking-tight">Edit Student Profile</h2>
          </div>
        </div>

        {isSaved && (
          <span className="flex items-center gap-1 text-xs text-emerald-400 font-semibold px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 animate-pulse">
            <CheckCircle2 className="w-3.5 h-3.5" /> Saved
          </span>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Profile Photo Upload Card */}
        <div className="bg-gradient-to-br from-slate-900 via-indigo-950/30 to-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-4">
          <div className="text-xs font-bold text-slate-300 uppercase tracking-wide flex items-center gap-1.5">
            <Camera className="w-4 h-4 text-indigo-400" />
            <span>Profile Photo &amp; Avatar</span>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-5">
            {/* Big Avatar with overlay button */}
            <div className="relative group shrink-0">
              <img
                src={avatarUrl}
                alt={name}
                className="w-24 h-24 rounded-3xl object-cover ring-4 ring-indigo-500/30 shadow-xl"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 rounded-3xl bg-slate-950/60 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white text-[10px] font-bold transition duration-200 backdrop-blur-xs"
              >
                <Camera className="w-6 h-6 mb-1 text-indigo-400" />
                Change
              </button>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg flex items-center justify-center transition active:scale-95"
                title="Upload Photo"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>

            {/* Photo Actions & Info */}
            <div className="flex-1 space-y-2 text-center sm:text-left">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />

              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload From Device</span>
                </button>

                <button
                  type="button"
                  onClick={handleResetToDefaultPhoto}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
                  <span>Reset Default</span>
                </button>
              </div>

              {photoSourceNote && (
                <p className="text-[11px] text-emerald-400 font-medium">
                  {photoSourceNote}
                </p>
              )}

              <p className="text-[11px] text-slate-400">
                Recommended: Square image under 5MB (JPG, PNG, WebP). Persisted locally in offline database.
              </p>
            </div>
          </div>

          {/* Preset Avatars Selector */}
          <div className="pt-3 border-t border-slate-800/80 space-y-2">
            <span className="text-[11px] font-semibold text-slate-400">Or choose a preset student avatar:</span>
            <div className="flex items-center gap-2.5 overflow-x-auto pb-1 scrollbar-none">
              {PRESET_AVATARS.map((av, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setAvatarUrl(av.url);
                    setPhotoSourceNote(`Selected preset: ${av.name}`);
                  }}
                  className={`relative shrink-0 rounded-2xl overflow-hidden ring-2 transition active:scale-95 ${
                    avatarUrl === av.url ? 'ring-indigo-500 scale-105' : 'ring-transparent hover:ring-slate-700'
                  }`}
                  title={av.name}
                >
                  <img src={av.url} alt={av.name} className="w-12 h-12 object-cover" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Personal & Academic Details Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-3.5">
          <div className="text-xs font-bold text-slate-300 uppercase tracking-wide flex items-center gap-1.5">
            <GraduationCap className="w-4 h-4 text-indigo-400" />
            <span>Academic &amp; Student Information</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-slate-400" /> Full Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Student Name"
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                <GraduationCap className="w-3.5 h-3.5 text-slate-400" /> Class / Grade *
              </label>
              <input
                type="text"
                required
                value={studentClass}
                onChange={e => setStudentClass(e.target.value)}
                placeholder="e.g. 9"
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                <Hash className="w-3.5 h-3.5 text-slate-400" /> Roll Number
              </label>
              <input
                type="text"
                value={rollNumber}
                onChange={e => setRollNumber(e.target.value)}
                placeholder="e.g. 09"
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" /> Country *
              </label>
              <input
                type="text"
                required
                value={country}
                onChange={e => setCountry(e.target.value)}
                placeholder="Nepal"
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
              <School className="w-3.5 h-3.5 text-slate-400" /> School / Academy Name
            </label>
            <input
              type="text"
              value={schoolName}
              onChange={e => setSchoolName(e.target.value)}
              placeholder="e.g. Kathmandu Model Academy"
              className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-slate-400" /> Academic Session
            </label>
            <input
              type="text"
              value={academicYear}
              onChange={e => setAcademicYear(e.target.value)}
              placeholder="e.g. 2026-2027 AD (2083 BS)"
              className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-slate-400" /> Time Zone
            </label>
            <input
              type="text"
              readOnly
              value={`${timeZone} (Nepal Standard Time, UTC+05:45)`}
              className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-950/60 border border-slate-800 text-xs font-mono text-indigo-300 cursor-not-allowed"
            />
          </div>
        </div>

        {/* Save Button */}
        <div className="flex items-center gap-2 pt-1">
          <button
            type="button"
            onClick={onBack}
            className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="flex-1 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 active:scale-98 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-indigo-600/30 transition"
          >
            <Save className="w-4 h-4" />
            <span>Save Profile</span>
          </button>
        </div>
      </form>
    </div>
  );
};
