import React, { useState } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  XCircle,
  ClockAlert,
  Sparkles,
  Edit3,
  Trash2,
  FileText,
  AlertTriangle,
  X,
  Sparkles as SparklesIcon
} from 'lucide-react';
import {
  AttendanceRecord,
  AttendanceStatus,
  WorkingDaysConfig,
  HolidayItem
} from '../types';
import {
  MONTH_NAMES,
  getDaysInMonth,
  getFirstDayOfMonth,
  getNepalTimeDetails
} from '../utils/nepalTime';
import { getBikramSambatDetails } from '../utils/bikramSambat';
import { isWorkingDay } from '../utils/storage';

interface AttendanceTabProps {
  attendanceRecords: Record<string, AttendanceRecord>;
  workingDays: WorkingDaysConfig;
  holidays: HolidayItem[];
  onSaveRecord: (record: AttendanceRecord) => void;
  onDeleteRecord: (dateStr: string) => void;
}

export const AttendanceTab: React.FC<AttendanceTabProps> = ({
  attendanceRecords,
  workingDays,
  holidays,
  onSaveRecord,
  onDeleteRecord
}) => {
  const currentNepal = getNepalTimeDetails();
  const [selectedYear, setSelectedYear] = useState<number>(currentNepal.year);
  const [selectedMonthIndex, setSelectedMonthIndex] = useState<number>(currentNepal.month - 1); // 0-11
  
  // Selected Day Drawer / Modal
  const [activeDateStr, setActiveDateStr] = useState<string | null>(null);
  const [editStatus, setEditStatus] = useState<AttendanceStatus>('PRESENT');
  const [editNotes, setEditNotes] = useState<string>('');
  const [duplicateWarning, setDuplicateWarning] = useState<boolean>(false);

  const daysInMonth = getDaysInMonth(selectedYear, selectedMonthIndex);
  const firstDay = getFirstDayOfMonth(selectedYear, selectedMonthIndex); // 0=Sunday
  const pad = (n: number) => n.toString().padStart(2, '0');

  const handlePrevMonth = () => {
    if (selectedMonthIndex === 0) {
      setSelectedMonthIndex(11);
      setSelectedYear(prev => prev - 1);
    } else {
      setSelectedMonthIndex(prev => prev - 1);
    }
  };

  const handleNextMonth = () => {
    if (selectedMonthIndex === 11) {
      setSelectedMonthIndex(0);
      setSelectedYear(prev => prev + 1);
    } else {
      setSelectedMonthIndex(prev => prev + 1);
    }
  };

  const handleJumpToToday = () => {
    setSelectedYear(currentNepal.year);
    setSelectedMonthIndex(currentNepal.month - 1);
  };

  const openDayDetails = (dayNum: number) => {
    const dateStr = `${selectedYear}-${pad(selectedMonthIndex + 1)}-${pad(dayNum)}`;
    const existing = attendanceRecords[dateStr];

    setActiveDateStr(dateStr);
    setDuplicateWarning(!!existing);
    if (existing) {
      setEditStatus(existing.status);
      setEditNotes(existing.notes || '');
    } else {
      // Check if it's Sunday-Fri or holiday default
      const dateObj = new Date(selectedYear, selectedMonthIndex, dayNum);
      const isOfficialHoliday = holidays.some(h => h.date === dateStr);
      const isWork = isWorkingDay(dateObj, workingDays);

      if (isOfficialHoliday || !isWork) {
        setEditStatus('HOLIDAY');
        setEditNotes(isOfficialHoliday ? (holidays.find(h => h.date === dateStr)?.name || 'Official Holiday') : 'Weekly Off');
      } else {
        setEditStatus('PRESENT');
        setEditNotes('');
      }
    }
  };

  const handleSave = () => {
    if (!activeDateStr) return;
    onSaveRecord({
      id: activeDateStr,
      date: activeDateStr,
      status: editStatus,
      notes: editNotes.trim(),
      timestamp: Date.now()
    });
    setActiveDateStr(null);
  };

  const handleDelete = () => {
    if (!activeDateStr) return;
    onDeleteRecord(activeDateStr);
    setActiveDateStr(null);
  };

  // Calendar Day Status Styles
  const getDayStyle = (dateStr: string) => {
    const rec = attendanceRecords[dateStr];
    if (!rec) {
      // Check if official holiday
      if (holidays.some(h => h.date === dateStr)) {
        return 'bg-indigo-500/10 text-indigo-300 border-dashed border-indigo-500/40';
      }
      return 'bg-slate-900/60 text-slate-400 border-slate-800 hover:border-slate-700';
    }

    switch (rec.status) {
      case 'PRESENT':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 font-bold shadow-sm shadow-emerald-500/10';
      case 'ABSENT':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/50 font-bold shadow-sm shadow-rose-500/10';
      case 'LEAVE':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/50 font-bold shadow-sm shadow-amber-500/10';
      case 'HOLIDAY':
        return 'bg-indigo-500/20 text-indigo-300 border-indigo-500/50 font-bold';
    }
  };

  // Monthly Quick Summary for active view
  let monthPresent = 0;
  let monthAbsent = 0;
  let monthLeave = 0;
  let monthHoliday = 0;

  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = `${selectedYear}-${pad(selectedMonthIndex + 1)}-${pad(d)}`;
    const rec = attendanceRecords[dateStr];
    if (rec) {
      if (rec.status === 'PRESENT') monthPresent++;
      else if (rec.status === 'ABSENT') monthAbsent++;
      else if (rec.status === 'LEAVE') monthLeave++;
      else if (rec.status === 'HOLIDAY') monthHoliday++;
    }
  }

  // Bikram Sambat representation for this month
  const monthStartBS = getBikramSambatDetails(`${selectedYear}-${pad(selectedMonthIndex + 1)}-01`);
  const monthEndBS = getBikramSambatDetails(`${selectedYear}-${pad(selectedMonthIndex + 1)}-${pad(daysInMonth)}`);

  return (
    <div className="space-y-4 pb-20">
      {/* Month Header & Switcher */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[11px] font-semibold text-amber-300 uppercase tracking-wide flex items-center gap-1.5">
              <SparklesIcon className="w-3.5 h-3.5 text-amber-400" />
              <span>
                {monthStartBS.monthNameNp === monthEndBS.monthNameNp
                  ? `${monthStartBS.monthNameNp} ${monthStartBS.yearNp} वि.सं.`
                  : `${monthStartBS.monthNameNp} / ${monthEndBS.monthNameNp} ${monthStartBS.yearNp} वि.सं.`}
              </span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight flex items-baseline gap-2">
              <span>{MONTH_NAMES[selectedMonthIndex]} {selectedYear}</span>
              <span className="text-xs font-normal text-slate-400">
                ({monthStartBS.monthNameEn} {monthStartBS.year} BS)
              </span>
            </h2>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleJumpToToday}
              className="text-[11px] font-semibold px-2.5 py-1 rounded-lg bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 hover:bg-indigo-500/25 transition active:scale-95"
            >
              Today
            </button>
            <button
              onClick={handlePrevMonth}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
              title="Previous Month"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={handleNextMonth}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
              title="Next Month"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-3 pt-3 mt-3 border-t border-slate-800 text-[11px] text-slate-300">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span>Present ({monthPresent})</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
            <span>Absent ({monthAbsent})</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            <span>Leave ({monthLeave})</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
            <span>Holiday ({monthHoliday})</span>
          </div>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-lg">
        {/* Days of Week Header */}
        <div className="grid grid-cols-7 gap-1 text-center mb-2">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, idx) => (
            <div
              key={day}
              className={`text-xs font-semibold py-1 uppercase tracking-wider ${
                idx === 6 ? 'text-indigo-400' : 'text-slate-400'
              }`}
            >
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Days */}
        <div className="grid grid-cols-7 gap-1.5">
          {/* Empty cells before month start */}
          {Array.from({ length: firstDay }).map((_, i) => (
            <div key={`empty-${i}`} className="aspect-square rounded-xl bg-transparent" />
          ))}

          {/* Actual days */}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const dayNum = i + 1;
            const dateStr = `${selectedYear}-${pad(selectedMonthIndex + 1)}-${pad(dayNum)}`;
            const isToday = dateStr === currentNepal.isoDate;
            const record = attendanceRecords[dateStr];
            const hasNotes = !!record?.notes;

            return (
              <button
                key={dateStr}
                onClick={() => openDayDetails(dayNum)}
                className={`relative aspect-square rounded-xl border flex flex-col items-center justify-center p-1 transition active:scale-95 text-xs select-none ${getDayStyle(
                  dateStr
                )} ${isToday ? 'ring-2 ring-indigo-400 ring-offset-2 ring-offset-slate-900' : ''}`}
              >
                <span className="font-semibold">{dayNum}</span>
                {record && (
                  <span className="text-[9px] uppercase font-bold tracking-tight scale-90">
                    {record.status[0]}
                  </span>
                )}
                {hasNotes && (
                  <span className="absolute bottom-1 w-1 h-1 rounded-full bg-indigo-400" />
                )}
                {isToday && (
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-indigo-500 animate-ping" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Quick Help Tip */}
      <div className="flex items-center gap-2 p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-300">
        <FileText className="w-4 h-4 shrink-0 text-indigo-400" />
        <span>Tap any date on the calendar to mark, update, or add notes to an attendance record.</span>
      </div>

      {/* Edit / Mark Attendance Modal */}
      {activeDateStr && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="relative w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl space-y-4">
            <button
              onClick={() => setActiveDateStr(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1.5 rounded-full hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            {activeDateStr && (() => {
              const activeBs = getBikramSambatDetails(activeDateStr);
              return (
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
                    <CalendarIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Record Attendance</h3>
                    <div className="text-xs font-semibold text-amber-300">
                      {activeBs.formattedNp}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      AD: {activeDateStr} &bull; {activeBs.formattedShortEn}
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* Duplicate Entry Prevention Notice */}
            {duplicateWarning && (
              <div className="flex items-start gap-2 p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
                <div>
                  <span className="font-semibold">Existing entry found.</span> Modifying will update the previous record for this date safely.
                </div>
              </div>
            )}

            {/* Status Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Select Status</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setEditStatus('PRESENT')}
                  className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center gap-2 border transition ${
                    editStatus === 'PRESENT'
                      ? 'bg-emerald-600 text-white border-emerald-500'
                      : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Present</span>
                </button>
                <button
                  type="button"
                  onClick={() => setEditStatus('ABSENT')}
                  className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center gap-2 border transition ${
                    editStatus === 'ABSENT'
                      ? 'bg-rose-600 text-white border-rose-500'
                      : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  <XCircle className="w-4 h-4 text-rose-400" />
                  <span>Absent</span>
                </button>
                <button
                  type="button"
                  onClick={() => setEditStatus('LEAVE')}
                  className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center gap-2 border transition ${
                    editStatus === 'LEAVE'
                      ? 'bg-amber-600 text-white border-amber-500'
                      : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  <ClockAlert className="w-4 h-4 text-amber-400" />
                  <span>Leave</span>
                </button>
                <button
                  type="button"
                  onClick={() => setEditStatus('HOLIDAY')}
                  className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center gap-2 border transition ${
                    editStatus === 'HOLIDAY'
                      ? 'bg-indigo-600 text-white border-indigo-500'
                      : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  <Sparkles className="w-4 h-4 text-indigo-400" />
                  <span>Holiday</span>
                </button>
              </div>
            </div>

            {/* Daily Note */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Edit3 className="w-3.5 h-3.5 text-slate-400" />
                Notes &amp; Reasons (Optional)
              </label>
              <textarea
                value={editNotes}
                onChange={e => setEditNotes(e.target.value)}
                placeholder="e.g. Science test, doctor visit, festival celebration..."
                rows={3}
                className="w-full rounded-xl bg-slate-950 border border-slate-800 p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 pt-2">
              {duplicateWarning && (
                <button
                  type="button"
                  onClick={handleDelete}
                  className="p-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/25 transition"
                  title="Delete Record"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
              <button
                type="button"
                onClick={handleSave}
                className="flex-1 py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:scale-98 text-white font-semibold text-xs shadow-lg shadow-indigo-600/30 transition"
              >
                Save Attendance Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
